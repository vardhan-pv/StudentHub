import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { successResponse, errorResponse, validateAuthHeader } from '@/lib/api-response';
import { z } from 'zod';

// Initialize Razorpay client when needed
const getRazorpayInstance = () => {
  try {
    // Razorpay would be imported dynamically when available
    return null;
  } catch {
    return null;
  }
};

const createOrderSchema = z.object({
  projectId: z.string(),
});

// GET /api/orders - Get user's orders
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    const { valid, token } = validateAuthHeader(authHeader || '');

    if (!valid) {
      return NextResponse.json(
        errorResponse('Unauthorized'),
        { status: 401 }
      );
    }

    const tokenData = verifyToken(token!);
    if (!tokenData || typeof tokenData === 'string') {
      return NextResponse.json(
        errorResponse('Invalid token'),
        { status: 401 }
      );
    }

    const userId = (tokenData as any).userId;
    const { db } = await connectToDatabase();

    const orders = await db
      .collection('orders')
      .find({
        $or: [
          { buyerId: userId },
          { sellerId: userId },
        ],
      })
      .sort({ createdAt: -1 })
      .toArray();

    return NextResponse.json(successResponse({ orders }));
  } catch (error) {
    console.error('Orders fetch error:', error);
    return NextResponse.json(
      errorResponse('Failed to fetch orders'),
      { status: 500 }
    );
  }
}

// POST /api/orders - Create order
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    const { valid, token } = validateAuthHeader(authHeader || '');

    if (!valid) {
      return NextResponse.json(
        errorResponse('Unauthorized'),
        { status: 401 }
      );
    }

    const tokenData = verifyToken(token!);
    if (!tokenData || typeof tokenData === 'string') {
      return NextResponse.json(
        errorResponse('Invalid token'),
        { status: 401 }
      );
    }

    const userId = (tokenData as any).userId;
    const body = await request.json();

    const validation = createOrderSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        errorResponse('Invalid order data'),
        { status: 400 }
      );
    }

    const { projectId } = validation.data;
    const { db } = await connectToDatabase();

    // Get project
    const project = await db.collection('projects').findOne({
      _id: new ObjectId(projectId),
    });

    if (!project) {
      return NextResponse.json(
        errorResponse('Project not found'),
        { status: 404 }
      );
    }

    // Get buyer info
    const buyer = await db.collection('users').findOne({
      _id: new ObjectId(userId),
    });

    if (!buyer) {
      return NextResponse.json(
        errorResponse('User not found'),
        { status: 404 }
      );
    }

    // Create Razorpay order
    const razorpayOrder = await razorpay.orders.create({
      amount: project.price * 100, // Convert to paise
      currency: 'INR',
      receipt: `order_${projectId}_${userId}`,
      notes: {
        projectId,
        buyerId: userId,
      },
    });

    // Create order in DB
    const result = await db.collection('orders').insertOne({
      buyerId: new ObjectId(userId),
      buyerUsername: buyer.username,
      sellerId: project.sellerId,
      sellerUsername: project.sellerUsername,
      projectId: new ObjectId(projectId),
      projectTitle: project.title,
      price: project.price,
      razorpayOrderId: razorpayOrder.id,
      status: 'pending',
      downloadCount: 0,
      maxDownloads: 5,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    return NextResponse.json(
      successResponse(
        {
          orderId: result.insertedId,
          razorpayOrderId: razorpayOrder.id,
          amount: project.price,
          projectTitle: project.title,
        },
        'Order created successfully',
        201
      ),
      { status: 201 }
    );
  } catch (error) {
    console.error('Order creation error:', error);
    return NextResponse.json(
      errorResponse('Failed to create order'),
      { status: 500 }
    );
  }
}
