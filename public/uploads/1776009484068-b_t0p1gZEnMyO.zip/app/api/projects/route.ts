import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { successResponse, errorResponse, validateAuthHeader, paginate } from '@/lib/api-response';
import { z } from 'zod';

const createProjectSchema = z.object({
  title: z.string().min(5).max(200),
  description: z.string().min(20),
  category: z.string().min(3),
  price: z.number().positive(),
  fileUrl: z.string().url(),
  fileKey: z.string(),
  fileName: z.string(),
  fileSize: z.number().positive(),
  metadata: z.object({
    tags: z.array(z.string()).min(1),
    language: z.string().optional(),
    framework: z.string().optional(),
    techStack: z.array(z.string()).optional(),
  }),
});

// GET /api/projects - List all projects with filters
export async function GET(request: NextRequest) {
  try {
    const { db } = await connectToDatabase();
    const url = new URL(request.url);
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const limit = Math.min(20, parseInt(url.searchParams.get('limit') || '10'));
    const category = url.searchParams.get('category');
    const search = url.searchParams.get('search');
    const sellerId = url.searchParams.get('sellerId');

    // Build filter
    const filter: any = {};
    if (category) filter.category = category;
    if (sellerId) filter.sellerId = sellerId;
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { 'metadata.tags': { $in: [search] } },
      ];
    }

    // Get total count
    const total = await db.collection('projects').countDocuments(filter);

    // Get paginated results
    const { skip } = paginate(total, limit, page);
    const projects = await db
      .collection('projects')
      .find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .toArray();

    return NextResponse.json(
      successResponse({
        projects,
        pagination: {
          total,
          page,
          limit,
          pages: Math.ceil(total / limit),
        },
      })
    );
  } catch (error) {
    console.error('Projects fetch error:', error);
    return NextResponse.json(
      errorResponse('Failed to fetch projects'),
      { status: 500 }
    );
  }
}

// POST /api/projects - Create a new project
export async function POST(request: NextRequest) {
  try {
    // Verify auth
    const authHeader = request.headers.get('authorization');
    const { valid, token } = validateAuthHeader(authHeader || '');
    if (!valid) {
      return NextResponse.json(
        errorResponse('Unauthorized'),
        { status: 401 }
      );
    }

    const tokenData = verifyToken(token!);
    if (!tokenData || typeof tokenData === 'string') {
      return NextResponse.json(
        errorResponse('Invalid token'),
        { status: 401 }
      );
    }

    const userId = (tokenData as any).userId;
    const userRole = (tokenData as any).role;

    if (userRole !== 'seller' && userRole !== 'both') {
      return NextResponse.json(
        errorResponse('Only sellers can create projects'),
        { status: 403 }
      );
    }

    const body = await request.json();
    const validation = createProjectSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        errorResponse('Invalid project data'),
        { status: 400 }
      );
    }

    const { db } = await connectToDatabase();

    // Get user info
    const user = await db.collection('users').findOne({ _id: new ObjectId(userId) });
    if (!user) {
      return NextResponse.json(
        errorResponse('User not found'),
        { status: 404 }
      );
    }

    // Create project
    const result = await db.collection('projects').insertOne({
      ...validation.data,
      sellerId: new ObjectId(userId),
      sellerUsername: user.username,
      downloads: 0,
      rating: 0,
      reviews: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    return NextResponse.json(
      successResponse(
        {
          projectId: result.insertedId,
          ...validation.data,
        },
        'Project created successfully',
        201
      ),
      { status: 201 }
    );
  } catch (error) {
    console.error('Project creation error:', error);
    return NextResponse.json(
      errorResponse('Failed to create project'),
      { status: 500 }
    );
  }
}
