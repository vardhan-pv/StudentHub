import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { hashPassword, validateEmail, validatePassword } from '@/lib/auth';
import { successResponse, errorResponse } from '@/lib/api-response';
import { z } from 'zod';

const registerSchema = z.object({
  email: z.string().email('Invalid email'),
  username: z.string().min(3).max(20),
  fullName: z.string().min(2),
  password: z.string().min(8),
  role: z.enum(['buyer', 'seller', 'both']),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate request
    const validation = registerSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        errorResponse('Invalid input data'),
        { status: 400 }
      );
    }

    const { email, username, fullName, password, role } = validation.data;

    // Validate email format
    const isValidEmail = await validateEmail(email);
    if (!isValidEmail) {
      return NextResponse.json(
        errorResponse('Invalid email format'),
        { status: 400 }
      );
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      return NextResponse.json(
        errorResponse(passwordValidation.errors.join(', ')),
        { status: 400 }
      );
    }

    const { db } = await connectToDatabase();

    // Check if user already exists
    const existingUser = await db.collection('users').findOne({
      $or: [{ email }, { username }],
    });

    if (existingUser) {
      return NextResponse.json(
        errorResponse('User already exists'),
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const result = await db.collection('users').insertOne({
      email,
      username,
      fullName,
      password: hashedPassword,
      role,
      avatar: null,
      bio: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    return NextResponse.json(
      successResponse(
        {
          userId: result.insertedId,
          email,
          username,
          fullName,
          role,
        },
        'User registered successfully',
        201
      ),
      { status: 201 }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      errorResponse('Internal server error'),
      { status: 500 }
    );
  }
}
