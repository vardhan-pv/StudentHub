import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { successResponse, errorResponse, validateAuthHeader } from '@/lib/api-response';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    const { valid, token } = validateAuthHeader(authHeader || '');

    if (!valid) {
      return NextResponse.json(
        errorResponse('Unauthorized'),
        { status: 401 }
      );
    }

    const tokenData = verifyToken(token!);
    if (!tokenData || typeof tokenData === 'string') {
      return NextResponse.json(
        errorResponse('Invalid token'),
        { status: 401 }
      );
    }

    const userId = (tokenData as any).userId;
    const userRole = (tokenData as any).role;

    if (userRole !== 'seller' && userRole !== 'both') {
      return NextResponse.json(
        errorResponse('Access denied'),
        { status: 403 }
      );
    }

    const { db } = await connectToDatabase();
    const userObjectId = new ObjectId(userId);

    // Get seller's projects
    const projects = await db
      .collection('projects')
      .find({ sellerId: userObjectId })
      .toArray();

    const totalProjects = projects.length;
    const totalDownloads = projects.reduce((sum, p) => sum + (p.downloads || 0), 0);

    // Get completed orders
    const orders = await db
      .collection('orders')
      .find({
        sellerId: userObjectId,
        status: 'completed',
      })
      .toArray();

    const totalSales = orders.length;
    const totalEarnings = orders.reduce((sum, o) => sum + o.price, 0);

    // Get recent sales (last 30 days)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const recentOrders = await db
      .collection('orders')
      .find({
        sellerId: userObjectId,
        status: 'completed',
        createdAt: { $gte: thirtyDaysAgo },
      })
      .sort({ createdAt: -1 })
      .limit(10)
      .toArray();

    const recentSales = recentOrders.map((order) => ({
      projectTitle: order.projectTitle,
      buyerUsername: order.buyerUsername,
      amount: order.price,
      date: order.createdAt,
    }));

    // Get top projects
    const topProjects = projects
      .sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
      .slice(0, 5)
      .map((p) => ({
        title: p.title,
        downloads: p.downloads,
        price: p.price,
        rating: p.rating,
      }));

    return NextResponse.json(
      successResponse({
        stats: {
          totalProjects,
          totalSales,
          totalDownloads,
          totalEarnings,
          averageProjectPrice: totalProjects > 0 ? projects.reduce((sum, p) => sum + p.price, 0) / totalProjects : 0,
        },
        recentSales,
        topProjects,
      })
    );
  } catch (error) {
    console.error('Dashboard fetch error:', error);
    return NextResponse.json(
      errorResponse('Failed to fetch dashboard data'),
      { status: 500 }
    );
  }
}
