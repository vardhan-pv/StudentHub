'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, Filter, Star, Download, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';

const CATEGORIES = [
  'Web Development',
  'Mobile Development',
  'Data Science',
  'Machine Learning',
  'Python',
  'JavaScript',
  'React',
  'Database Design',
  'Cloud Computing',
  'Other',
];

export default function MarketplacePage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchProjects();
  }, [page, selectedCategory]);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      let url = `/api/projects?page=${page}&limit=12`;
      if (selectedCategory) url += `&category=${selectedCategory}`;

      const response = await fetch(url);
      const data = await response.json();
      if (data.success) {
        setProjects(data.data.projects);
        setTotalPages(data.data.pagination.pages);
      }
    } catch (error) {
      console.error('Failed to fetch projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;

    try {
      setLoading(true);
      const response = await fetch(
        `/api/projects?search=${encodeURIComponent(searchTerm)}&limit=12`
      );
      const data = await response.json();
      if (data.success) {
        setProjects(data.data.projects);
        setTotalPages(data.data.pagination.pages);
        setPage(1);
      }
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">SH</span>
            </div>
            <span className="font-bold text-lg">Student Hub</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/marketplace">
              <Button variant="ghost">Marketplace</Button>
            </Link>
            <Link href="/login">
              <Button variant="ghost">Login</Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="mb-8">
          <div className="flex gap-2">
            <Input
              placeholder="Search projects by title, category, or tags..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 py-3 text-base"
            />
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 px-8">
              <Search className="w-5 h-5 mr-2" />
              Search
            </Button>
          </div>
        </form>

        <div className="flex gap-8">
          {/* Filters Sidebar */}
          <div className={`${showFilters ? 'block' : 'hidden'} md:block w-full md:w-64 flex-shrink-0`}>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-6 md:block">
                <h3 className="font-semibold text-lg">Filters</h3>
                <button
                  onClick={() => setShowFilters(false)}
                  className="md:hidden text-gray-500 hover:text-gray-700"
                >
                  ×
                </button>
              </div>

              <div>
                <h4 className="font-semibold mb-4 text-sm">Category</h4>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="category"
                      value=""
                      checked={selectedCategory === ''}
                      onChange={() => {
                        setSelectedCategory('');
                        setPage(1);
                      }}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">All Categories</span>
                  </label>
                  {CATEGORIES.map((category) => (
                    <label key={category} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="category"
                        value={category}
                        checked={selectedCategory === category}
                        onChange={() => {
                          setSelectedCategory(category);
                          setPage(1);
                        }}
                        className="w-4 h-4"
                      />
                      <span className="text-sm">{category}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Projects Grid */}
          <div className="flex-1">
            {/* Mobile Filter Button */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="md:hidden mb-4 flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              <Filter className="w-5 h-5" />
              Filters
            </button>

            {loading ? (
              <div className="text-center py-12">Loading projects...</div>
            ) : projects.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-600 mb-4">No projects found</p>
                <Link href="/marketplace">
                  <Button className="bg-blue-600 hover:bg-blue-700">Clear Filters</Button>
                </Link>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {projects.map((project: any) => (
                    <Link key={project._id} href={`/project/${project._id}`}>
                      <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full flex flex-col">
                        <div className="p-6 flex-1 flex flex-col">
                          <div className="mb-3">
                            <span className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-semibold">
                              {project.category}
                            </span>
                          </div>

                          <h3 className="text-lg font-semibold mb-2 line-clamp-2 flex-1">{project.title}</h3>
                          <p className="text-gray-600 text-sm mb-4 line-clamp-2">{project.description}</p>

                          <div className="space-y-2 text-sm mb-4">
                            <p className="text-gray-600">by <span className="font-medium">{project.sellerUsername}</span></p>
                            {project.metadata?.tags && project.metadata.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {project.metadata.tags.slice(0, 3).map((tag: string) => (
                                  <span key={tag} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center justify-between pt-4 border-t mt-auto">
                            <div className="flex items-center gap-3">
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                <span className="text-sm font-medium">{project.rating || 0}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Download className="w-4 h-4 text-gray-500" />
                                <span className="text-sm text-gray-600">{project.downloads}</span>
                              </div>
                            </div>
                            <div className="text-lg font-bold text-blue-600">₹{project.price}</div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center items-center gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setPage(Math.max(1, page - 1))}
                      disabled={page === 1}
                    >
                      Previous
                    </Button>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                        <button
                          key={p}
                          onClick={() => setPage(p)}
                          className={`px-3 py-2 rounded ${
                            page === p
                              ? 'bg-blue-600 text-white'
                              : 'bg-white text-gray-700 border hover:bg-gray-50'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => setPage(Math.min(totalPages, page + 1))}
                      disabled={page === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
