'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { TrendingUp, Download, ShoppingCart, Plus, Settings, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default function SellerDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const token = localStorage.getItem('auth_token');

    if (!storedUser || !token) {
      router.push('/login');
      return;
    }

    const userData = JSON.parse(storedUser);
    if (userData.role !== 'seller' && userData.role !== 'both') {
      router.push('/marketplace');
      return;
    }

    setUser(userData);
    fetchDashboardData(token);
  }, [router]);

  const fetchDashboardData = async (token: string) => {
    try {
      const response = await fetch('/api/dashboard/seller', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to load dashboard');
        return;
      }

      setStats(data.data);
    } catch (err) {
      setError('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    router.push('/');
  };

  if (!user) {
    return <div>Redirecting...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">SH</span>
            </div>
            <span className="font-bold text-lg">Student Hub</span>
          </Link>

          <div className="flex items-center gap-4">
            <span className="text-gray-600">{user.username}</span>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="flex items-center gap-2">
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Seller Dashboard</h1>
          <div className="flex gap-4">
            <Link href="/dashboard/seller/upload">
              <Button className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Upload Project
              </Button>
            </Link>
            <Link href="/dashboard/seller/settings">
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Settings
              </Button>
            </Link>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
            {error}
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">Loading dashboard...</div>
        ) : stats ? (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Total Sales</p>
                    <p className="text-3xl font-bold">{stats.stats.totalSales}</p>
                  </div>
                  <ShoppingCart className="w-10 h-10 text-blue-600 opacity-20" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Total Earnings</p>
                    <p className="text-3xl font-bold">₹{stats.stats.totalEarnings}</p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-green-600 opacity-20" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Projects</p>
                    <p className="text-3xl font-bold">{stats.stats.totalProjects}</p>
                  </div>
                  <Plus className="w-10 h-10 text-purple-600 opacity-20" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Downloads</p>
                    <p className="text-3xl font-bold">{stats.stats.totalDownloads}</p>
                  </div>
                  <Download className="w-10 h-10 text-orange-600 opacity-20" />
                </div>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Recent Sales */}
              <div className="lg:col-span-2">
                <Card className="p-6">
                  <h2 className="text-xl font-bold mb-4">Recent Sales</h2>
                  {stats.recentSales.length === 0 ? (
                    <p className="text-gray-600 text-center py-8">No sales yet</p>
                  ) : (
                    <div className="space-y-4">
                      {stats.recentSales.map((sale: any, index: number) => (
                        <div key={index} className="flex items-center justify-between py-3 border-b last:border-b-0">
                          <div>
                            <p className="font-semibold">{sale.projectTitle}</p>
                            <p className="text-sm text-gray-600">by {sale.buyerUsername}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">+₹{sale.amount}</p>
                            <p className="text-xs text-gray-600">
                              {new Date(sale.date).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              </div>

              {/* Top Projects */}
              <div>
                <Card className="p-6">
                  <h2 className="text-xl font-bold mb-4">Top Projects</h2>
                  {stats.topProjects.length === 0 ? (
                    <p className="text-gray-600 text-center py-8">No projects yet</p>
                  ) : (
                    <div className="space-y-4">
                      {stats.topProjects.map((project: any, index: number) => (
                        <div key={index} className="pb-4 border-b last:border-b-0">
                          <p className="font-semibold text-sm line-clamp-1">{project.title}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-xs text-gray-600">
                              {project.downloads} downloads
                            </span>
                            <span className="text-sm font-bold">₹{project.price}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}
