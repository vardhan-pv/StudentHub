import crypto from 'crypto';

// Temporary in-memory database for development until MongoDB connects
interface InMemoryDb {
  users: any[];
  projects: any[];
  orders: any[];
  notifications: any[];
}

let memoryDb: InMemoryDb = {
  users: [],
  projects: [],
  orders: [],
  notifications: [],
};

let cachedDb: any = null;

export async function connectToDatabase() {
  if (cachedDb) {
    return { client: null, db: cachedDb };
  }

  // Try to connect to MongoDB if available, otherwise use in-memory db
  const uri = process.env.MONGODB_URI;
  
  try {
    if (uri) {
      const { MongoClient } = await import('mongodb');
      const client = new MongoClient(uri);
      await client.connect();
      cachedDb = client.db('student-hub');

      return { client, db: cachedDb };
    }
  } catch (error) {
    console.warn('MongoDB not available, using in-memory database:', error instanceof Error ? error.message : 'Unknown error');
  }
  
  // Fallback to in-memory database
  cachedDb = createInMemoryDbProxy();
  return { client: null, db: cachedDb };
}

function createInMemoryDbProxy() {
  return {
    collection: (name: string) => ({
      insertOne: async (doc: any) => ({ insertedId: crypto.randomUUID() }),
      insertMany: async (docs: any[]) => ({ insertedIds: docs.map(() => crypto.randomUUID()) }),
      findOne: async (query: any) => memoryDb[name as keyof InMemoryDb]?.find((doc: any) => Object.entries(query).every(([key, val]) => doc[key] === val)) || null,
      find: (query: any) => ({
        toArray: async () => memoryDb[name as keyof InMemoryDb]?.filter((doc: any) => Object.entries(query).every(([key, val]) => doc[key] === val)) || [],
        limit: function(n: number) { return this; },
        skip: function(n: number) { return this; },
        sort: function(sort: any) { return this; },
      }),
      updateOne: async (query: any, update: any) => ({ modifiedCount: 1 }),
      updateMany: async (query: any, update: any) => ({ modifiedCount: 1 }),
      deleteOne: async (query: any) => ({ deletedCount: 1 }),
      deleteMany: async (query: any) => ({ deletedCount: 1 }),
      countDocuments: async (query: any) => 0,
      createIndex: async () => {},
    }),
  };
}

export function getDatabase() {
  if (!cachedDb) {
    throw new Error('Database not connected');
  }
  return cachedDb;
}
