#!/bin/bash
# ============================================================
# Real-Time Mobile Storage Intelligence System
# Complete Quick Launch Script
# ============================================================

echo "🚀 Starting Real-Time Storage Intelligence System..."
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check prerequisites
echo -e "${BLUE}📋 Checking prerequisites...${NC}"

if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 is not installed${NC}"
    exit 1
fi

if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed${NC}"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ NPM is not installed${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All prerequisites met${NC}"
echo ""

# Setup Backend
echo -e "${BLUE}🔧 Setting up backend...${NC}"

cd backend || exit

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate || . venv/Scripts/activate

# Install dependencies
echo "Installing Python dependencies..."
pip install -q -r requirements.txt

echo -e "${GREEN}✅ Backend setup complete${NC}"
echo ""

# Start Backend (in background)
echo -e "${BLUE}🚀 Starting backend server...${NC}"
python main.py &
BACKEND_PID=$!
echo -e "${GREEN}✅ Backend started (PID: $BACKEND_PID)${NC}"
echo ""

# Setup Frontend
echo -e "${BLUE}🔧 Setting up frontend...${NC}"

cd ../frontend || exit

if [ ! -d "node_modules" ]; then
    echo "Installing npm dependencies..."
    npm install -q
fi

echo -e "${GREEN}✅ Frontend setup complete${NC}"
echo ""

# Start Frontend (in background)
echo -e "${BLUE}🚀 Starting frontend server...${NC}"
npm run dev &
FRONTEND_PID=$!
echo -e "${GREEN}✅ Frontend started (PID: $FRONTEND_PID)${NC}"
echo ""

# Display information
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}✨ System is Running!${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}📊 Frontend:${NC}"
echo "   URL: http://localhost:5173"
echo ""
echo -e "${YELLOW}🔌 Backend API:${NC}"
echo "   URL: http://localhost:8000"
echo "   Docs: http://localhost:8000/docs"
echo ""
echo -e "${YELLOW}🌐 WebSocket:${NC}"
echo "   URL: ws://localhost:8000/ws"
echo ""
echo -e "${YELLOW}📁 Project Structure:${NC}"
echo "   Backend: ./backend"
echo "   Frontend: ./frontend"
echo "   Docs: ./docs"
echo ""
echo -e "${YELLOW}📖 Documentation:${NC}"
echo "   Quick Start: ./QUICKSTART.md"
echo "   API Docs: ./docs/API_ENDPOINTS.md"
echo "   WebSocket: ./docs/WEBSOCKET_PROTOCOL.md"
echo "   Architecture: ./docs/ARCHITECTURE.md"
echo "   Deployment: ./docs/DEPLOYMENT.md"
echo ""
echo -e "${YELLOW}🛑 To stop the system:${NC}"
echo "   Press Ctrl+C in this terminal"
echo ""

# Keep script running
wait $BACKEND_PID $FRONTEND_PID

# Cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT
