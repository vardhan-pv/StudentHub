import React, { useEffect, useState } from 'react';
import { AlertCircle, TrendingUp, Zap } from 'lucide-react';
import useWebSocket from './hooks/useWebSocket';
import Dashboard from './components/Dashboard';
import './index.css';

function App() {
  const [isConnected, setIsConnected] = useState(false);
  const [systemStatus, setSystemStatus] = useState('connecting');
  const { data, isConnected: wsConnected } = useWebSocket('ws://localhost:8000/ws');

  useEffect(() => {
    setIsConnected(wsConnected);
    if (wsConnected) {
      setSystemStatus('running');
    } else {
      setSystemStatus('connecting');
    }
  }, [wsConnected]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">
                  Storage Intelligence
                </h1>
                <p className="text-sm text-slate-400">Real-time AI Monitoring</p>
              </div>
            </div>

            {/* Status Indicator */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full animate-pulse ${
                    isConnected ? 'bg-green-500' : 'bg-red-500'
                  }`}
                />
                <span className="text-sm text-slate-300">
                  {isConnected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Connection Alert */}
      {!isConnected && (
        <div className="bg-red-900/50 border-b border-red-700">
          <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400" />
              <span className="text-sm text-red-200">
                Attempting to connect to server... Make sure backend is running on
                localhost:8000
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {isConnected ? (
          <Dashboard data={data} />
        ) : (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <div className="animate-spin mb-4 inline-block">
                <Zap className="w-12 h-12 text-blue-500" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                Connecting to Server
              </h2>
              <p className="text-slate-400 mb-4">
                Ensure the FastAPI backend is running...
              </p>
              <code className="text-sm bg-slate-800 text-slate-200 px-4 py-2 rounded block">
                python main.py
              </code>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 backdrop-blur mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-white font-semibold mb-2">Real-time System</h3>
              <p className="text-sm text-slate-400">
                Continuous monitoring with AI predictions
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">Key Features</h3>
              <ul className="text-sm text-slate-400 space-y-1">
                <li>✨ Live storage updates</li>
                <li>🤖 AI predictions</li>
                <li>🚨 Smart alerts</li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-2">Status</h3>
              <p className="text-sm text-slate-400">
                Backend: <span className="text-green-400">Healthy</span>
              </p>
            </div>
          </div>
          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-sm text-slate-500">
            © 2026 Storage Intelligence System • Powered by FastAPI + React
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
