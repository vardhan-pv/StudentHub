import React, { useState } from 'react';
import { Sparkles, CheckCircle, ChevronDown } from 'lucide-react';

export default function RecommendationsPanel({ recommendations, storage }) {
  const [expandedRec, setExpandedRec] = useState(null);

  const getImpactColor = (impact) => {
    switch (impact) {
      case 'high':
        return 'text-green-400';
      case 'medium':
        return 'text-amber-400';
      case 'low':
        return 'text-blue-400';
      default:
        return 'text-slate-400';
    }
  };

  const getDifficultyBadge = (difficulty) => {
    switch (difficulty) {
      case 'very_easy':
        return { bg: 'bg-green-900/30', text: 'text-green-200', label: 'Very Easy' };
      case 'easy':
        return { bg: 'bg-blue-900/30', text: 'text-blue-200', label: 'Easy' };
      case 'medium':
        return { bg: 'bg-amber-900/30', text: 'text-amber-200', label: 'Medium' };
      default:
        return { bg: 'bg-slate-700', text: 'text-slate-200', label: 'Hard' };
    }
  };

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Sparkles className="w-5 h-5" />
        AI Recommendations
      </h2>

      {recommendations.length === 0 ? (
        <div className="text-center py-8">
          <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-2" />
          <p className="text-slate-400 text-sm">No immediate recommendations</p>
          <p className="text-slate-500 text-xs mt-1">Keep monitoring your storage</p>
        </div>
      ) : (
        <div className="space-y-3">
          {recommendations.map((rec, idx) => {
            const difficulty = getDifficultyBadge(rec.difficulty);
            const isExpanded = expandedRec === rec.id;

            return (
              <div
                key={rec.id || idx}
                className="bg-slate-700/50 border border-slate-600/50 rounded-lg overflow-hidden hover:border-slate-600 transition-colors"
              >
                {/* Header */}
                <button
                  onClick={() => setExpandedRec(isExpanded ? null : rec.id)}
                  className="w-full px-4 py-3 flex items-start justify-between hover:bg-slate-700/30 transition-colors"
                >
                  <div className="text-left flex-1">
                    <h3 className="font-semibold text-white text-sm mb-1">
                      {rec.title}
                    </h3>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-xs font-semibold ${difficulty.text} ${difficulty.bg} px-2 py-1 rounded`}>
                        {difficulty.label}
                      </span>
                      <span className={`text-xs font-semibold ${getImpactColor(rec.impact)}`}>
                        💾 {rec.freed_space_mb}MB potential
                      </span>
                      <span className="text-xs text-slate-500">
                        ⏱️ {rec.time_estimate}
                      </span>
                    </div>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 transition-transform ${
                      isExpanded ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {/* Expanded Content */}
                {isExpanded && (
                  <div className="px-4 py-3 border-t border-slate-600/50 bg-slate-800/50 space-y-3">
                    <p className="text-slate-300 text-sm">{rec.description}</p>

                    {rec.benefits && rec.benefits.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-slate-300 mb-2">
                          Benefits:
                        </p>
                        <ul className="space-y-1">
                          {rec.benefits.map((benefit, idx) => (
                            <li
                              key={idx}
                              className="text-xs text-slate-400 flex items-center gap-2"
                            >
                              <span className="text-green-400">✓</span>
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="flex gap-2 pt-3">
                      <button className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white text-sm font-semibold py-2 rounded transition-all">
                        Take Action
                      </button>
                      <button className="px-4 bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm font-semibold py-2 rounded transition-colors">
                        Learn More
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Summary Stats */}
      {recommendations.length > 0 && (
        <div className="mt-4 pt-4 border-t border-slate-700">
          <p className="text-xs text-slate-400">
            💾 Total potential space recovery:{' '}
            <span className="text-green-400 font-semibold">
              {(
                recommendations.reduce((sum, r) => sum + (r.freed_space_mb || 0), 0) / 1024
              ).toFixed(1)}
              GB
            </span>
          </p>
        </div>
      )}
    </div>
  );
}
