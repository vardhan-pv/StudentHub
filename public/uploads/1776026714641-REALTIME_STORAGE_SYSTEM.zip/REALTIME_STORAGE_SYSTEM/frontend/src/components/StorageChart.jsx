import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';

export default function StorageChart({ storage, history, predictions }) {
  // Prepare chart data combining history and predictions
  const chartData = history.map((point) => ({
    time: new Date(point.timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    }),
    used: parseFloat(point.used_gb.toFixed(1)),
    timestamp: point.timestamp,
  }));

  // Add some future prediction points (simulated)
  if (chartData.length > 0 && predictions.day_7) {
    const lastPoint = chartData[chartData.length - 1];
    chartData.push({
      time: 'Day 7',
      used: null,
      predicted: parseFloat(predictions.day_7.toFixed(1)),
      timestamp: 'predicted',
    });
    chartData.push({
      time: 'Day 15',
      used: null,
      predicted: parseFloat(predictions.day_15.toFixed(1)),
      timestamp: 'predicted',
    });
    chartData.push({
      time: 'Day 30',
      used: null,
      predicted: parseFloat(predictions.day_30.toFixed(1)),
      timestamp: 'predicted',
    });
  }

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700 rounded p-3 shadow-lg">
          <p className="text-slate-300 text-sm font-semibold">{data.time}</p>
          {data.used && <p className="text-blue-400 text-sm">Actual: {data.used}GB</p>}
          {data.predicted && <p className="text-amber-400 text-sm">Predicted: {data.predicted}GB</p>}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <h2 className="text-lg font-bold text-white mb-4">📈 Storage Trend & Prediction</h2>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis
            dataKey="time"
            stroke="#94a3b8"
            style={{ fontSize: '12px' }}
          />
          <YAxis
            stroke="#94a3b8"
            style={{ fontSize: '12px' }}
            domain={[0, 128]}
            label={{ value: 'Storage (GB)', angle: -90, position: 'insideLeft' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />

          {/* Critical Threshold Line */}
          <ReferenceLine
            y={115}
            stroke="#ef4444"
            strokeDasharray="5 5"
            label={{
              value: 'Critical (90%)',
              position: 'right',
              fill: '#ef4444',
              fontSize: 12,
            }}
          />

          {/* Warning Threshold Line */}
          <ReferenceLine
            y={102}
            stroke="#f97316"
            strokeDasharray="5 5"
            label={{
              value: 'Warning (80%)',
              position: 'right',
              fill: '#f97316',
              fontSize: 12,
            }}
          />

          {/* Actual Usage Line */}
          <Line
            type="monotone"
            dataKey="used"
            stroke="#3b82f6"
            strokeWidth={2}
            dot={false}
            name="Actual Usage"
            isAnimationActive={true}
            animationDuration={500}
          />

          {/* Predicted Usage Line */}
          <Line
            type="monotone"
            dataKey="predicted"
            stroke="#fbbf24"
            strokeWidth={2}
            strokeDasharray="5 5"
            dot={{ fill: '#fbbf24', r: 4 }}
            name="Predicted"
            isAnimationActive={true}
          />
        </LineChart>
      </ResponsiveContainer>

      {/* Chart Legend Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Current Usage</p>
          <p className="text-white font-semibold text-lg">
            {storage.used_gb.toFixed(1)}GB / {storage.total_gb}GB
          </p>
          <p className="text-blue-400 text-sm mt-1">
            {storage.usage_percent.toFixed(1)}% full
          </p>
        </div>

        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Growth Rate</p>
          <p className="text-white font-semibold text-lg">
            {storage.daily_growth_mb}MB/day
          </p>
          <p className="text-emerald-400 text-sm mt-1">
            ~{(storage.daily_growth_mb * 30 / 1024).toFixed(1)}GB/month
          </p>
        </div>

        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Days Until Critical</p>
          <p className="text-white font-semibold text-lg">
            {Math.max(0, Math.floor(((128 * 0.9) - storage.used_gb) / (storage.daily_growth_mb / 1024)))} days
          </p>
          <p className="text-amber-400 text-sm mt-1">
            at current growth rate
          </p>
        </div>
      </div>
    </div>
  );
}
