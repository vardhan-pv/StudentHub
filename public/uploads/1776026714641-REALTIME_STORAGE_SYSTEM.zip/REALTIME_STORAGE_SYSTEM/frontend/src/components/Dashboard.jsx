import React, { useState } from 'react';
import StorageMonitor from './StorageMonitor';
import StorageChart from './StorageChart';
import AlertsPanel from './AlertsPanel';
import RecommendationsPanel from './RecommendationsPanel';
import WhatIfSimulator from './WhatIfSimulator';

export default function Dashboard({ data }) {
  const [activeTab, setActiveTab] = useState('overview');

  if (!data || !data.storage) {
    return (
      <div className="text-center py-12">
        <div className="text-slate-400">Loading data...</div>
      </div>
    );
  }

  const storage = data.storage;
  const alerts = data.alerts || [];
  const recommendations = data.recommendations || [];
  const predictions = data.predictions || {};

  return (
    <div className="space-y-6">
      {/* Overview Tab */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Storage Monitor - Takes 2 cols */}
        <div className="lg:col-span-2">
          <StorageMonitor storage={storage} />
        </div>

        {/* Quick Stats */}
        <div className="space-y-4">
          {/* Status Card */}
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Status</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Status</span>
                <span
                  className={`text-sm font-semibold ${
                    storage.status === 'healthy'
                      ? 'text-green-400'
                      : storage.status === 'caution'
                      ? 'text-yellow-400'
                      : storage.status === 'warning'
                      ? 'text-orange-400'
                      : 'text-red-400'
                  }`}
                >
                  {storage.status.charAt(0).toUpperCase() + storage.status.slice(1)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Trend</span>
                <span className="text-slate-300 text-sm">{storage.trend}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Daily Growth</span>
                <span className="text-slate-300 text-sm">
                  {storage.daily_growth_mb}MB
                </span>
              </div>
            </div>
          </div>

          {/* Prediction Card */}
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Prediction</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">7 days</span>
                <span className="text-slate-300 font-semibold">
                  {predictions.day_7}GB
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">15 days</span>
                <span className="text-slate-300 font-semibold">
                  {predictions.day_15}GB
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">30 days</span>
                <span className="text-slate-300 font-semibold">
                  {predictions.day_30}GB
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Storage Chart */}
      <div>
        <StorageChart storage={storage} history={data.history || []} predictions={predictions} />
      </div>

      {/* Alerts and Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AlertsPanel alerts={alerts} />
        <RecommendationsPanel recommendations={recommendations} storage={storage} />
      </div>

      {/* What-If Simulator */}
      <div>
        <WhatIfSimulator storage={storage} predictions={predictions} />
      </div>

      {/* Categories Breakdown */}
      <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
        <h2 className="text-lg font-bold text-white mb-4">📁 Storage Breakdown</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {storage.categories &&
            storage.categories.map((cat) => (
              <div
                key={cat.name}
                className="bg-slate-700/50 rounded p-4 border border-slate-600"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-semibold">{cat.icon} {cat.name}</span>
                  <span className="text-blue-400 text-sm">{cat.percentage}%</span>
                </div>
                <div className="w-full bg-slate-600 rounded-full h-2 mb-2">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full"
                    style={{ width: `${Math.min(cat.percentage, 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-slate-400">
                  <span>{cat.size_gb}GB</span>
                  <span>+{cat.growth_rate_daily_mb}MB/day</span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
