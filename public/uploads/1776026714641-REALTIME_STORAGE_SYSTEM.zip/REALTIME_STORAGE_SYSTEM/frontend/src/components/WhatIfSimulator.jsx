import React, { useState } from 'react';
import { Zap, TrendingDown } from 'lucide-react';

export default function WhatIfSimulator({ storage, predictions }) {
  const [selectedApp, setSelectedApp] = useState('Photos');
  const [appSize, setAppSize] = useState(100);
  const [showResult, setShowResult] = useState(false);
  const [simResult, setSimResult] = useState(null);

  const apps = [
    { name: 'Photos', icon: '📷', defaultSize: 500 },
    { name: 'Videos', icon: '🎬', defaultSize: 300 },
    { name: 'Games', icon: '🎮', defaultSize: 800 },
    { name: 'Social Media', icon: '👥', defaultSize: 200 },
    { name: 'Documents', icon: '📄', defaultSize: 100 },
    { name: 'Music', icon: '🎵', defaultSize: 150 },
  ];

  const handleSimulate = async () => {
    const freedSpaceGb = appSize / 1024;
    const currentUsed = storage.used_gb;
    const newUsed = Math.max(currentUsed - freedSpaceGb, 0);

    // Simulate what happens to predictions
    const impactDay7 = Math.max(predictions.day_7 - freedSpaceGb, 0);
    const impactDay15 = Math.max(predictions.day_15 - freedSpaceGb, 0);
    const impactDay30 = Math.max(predictions.day_30 - freedSpaceGb, 0);

    setSimResult({
      freedSpaceGb: freedSpaceGb.toFixed(2),
      currentUsed,
      newUsed: newUsed.toFixed(2),
      newUsagePercent: ((newUsed / storage.total_gb) * 100).toFixed(1),
      currentUsagePercent: storage.usage_percent.toFixed(1),
      impactDay7: impactDay7.toFixed(2),
      impactDay15: impactDay15.toFixed(2),
      impactDay30: impactDay30.toFixed(2),
      daysSaved: Math.floor((freedSpaceGb / (storage.daily_growth_mb / 1024))),
    });

    setShowResult(true);
  };

  const selectedAppObj = apps.find(a => a.name === selectedApp);
  const freedSpacePercent = ((appSize / 1024) / storage.free_gb * 100).toFixed(1);

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Zap className="w-5 h-5" />
        What-If Simulator
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Simulator Controls */}
        <div>
          <p className="text-slate-300 text-sm mb-4">
            Select an app and simulate freeing space
          </p>

          {/* App Selection */}
          <div className="mb-4">
            <label className="text-slate-300 text-sm font-semibold mb-2 block">
              Select App
            </label>
            <div className="grid grid-cols-2 gap-2">
              {apps.map(app => (
                <button
                  key={app.name}
                  onClick={() => {
                    setSelectedApp(app.name);
                    setAppSize(app.defaultSize);
                    setShowResult(false);
                  }}
                  className={`p-3 rounded border text-left transition-all ${
                    selectedApp === app.name
                      ? 'bg-blue-900/50 border-blue-500'
                      : 'bg-slate-700/50 border-slate-600/50 hover:border-slate-600'
                  }`}
                >
                  <p className="font-semibold text-white">
                    {app.icon} {app.name}
                  </p>
                  <p className="text-xs text-slate-400">
                    ~{app.defaultSize}MB
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Size Slider */}
          <div className="mb-4">
            <label className="text-slate-300 text-sm font-semibold mb-2 block">
              App Size: {appSize}MB
            </label>
            <input
              type="range"
              min="50"
              max="2000"
              step="50"
              value={appSize}
              onChange={e => {
                setAppSize(parseInt(e.target.value));
                setShowResult(false);
              }}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-1">
              <span>50MB</span>
              <span>2000MB</span>
            </div>
          </div>

          {/* Simulate Button */}
          <button
            onClick={handleSimulate}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-semibold py-3 rounded-lg transition-all mb-4"
          >
            Run Simulation
          </button>

          {/* Current State */}
          <div className="bg-slate-700/50 rounded p-4 border border-slate-600/50">
            <p className="text-slate-400 text-xs mb-3 font-semibold">
              BEFORE (Current)
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-300">Used</span>
                <span className="text-white font-semibold">
                  {storage.used_gb.toFixed(1)}GB
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Usage</span>
                <span className="text-white font-semibold">
                  {storage.usage_percent.toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Free</span>
                <span className="text-white font-semibold">
                  {storage.free_gb.toFixed(1)}GB
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        <div>
          {showResult && simResult ? (
            <div className="space-y-4">
              {/* Status Change */}
              <div className="bg-green-900/20 border border-green-700/50 rounded p-4">
                <p className="text-green-200 text-sm font-semibold mb-3">
                  ✓ SIMULATION RESULTS
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-300">Space Freed</span>
                    <span className="text-green-400 font-semibold">
                      {simResult.freedSpaceGb}GB
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Days Extended</span>
                    <span className="text-green-400 font-semibold">
                      +{simResult.daysSaved} days
                    </span>
                  </div>
                </div>
              </div>

              {/* After State */}
              <div className="bg-slate-700/50 rounded p-4 border border-slate-600/50">
                <p className="text-slate-400 text-xs mb-3 font-semibold">
                  AFTER (After Deletion)
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-300">Used</span>
                    <span className="text-cyan-400 font-semibold">
                      {simResult.newUsed}GB
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Usage</span>
                    <span className="text-cyan-400 font-semibold">
                      {simResult.newUsagePercent}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Change</span>
                    <span className="text-green-400 font-semibold">
                      -{simResult.freedSpaceGb}GB
                    </span>
                  </div>
                </div>
              </div>

              {/* Impact on Predictions */}
              <div className="bg-amber-900/20 border border-amber-700/50 rounded p-4">
                <p className="text-amber-200 text-xs font-semibold mb-3 flex items-center gap-2">
                  <TrendingDown className="w-4 h-4" />
                  IMPACT ON PREDICTIONS
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-300">Day 7</span>
                    <div className="text-right">
                      <p className="text-amber-400 font-semibold">
                        {simResult.impactDay7}GB
                      </p>
                      <p className="text-amber-600 text-xs">
                        (was {predictions.day_7}GB)
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Day 15</span>
                    <div className="text-right">
                      <p className="text-amber-400 font-semibold">
                        {simResult.impactDay15}GB
                      </p>
                      <p className="text-amber-600 text-xs">
                        (was {predictions.day_15}GB)
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Day 30</span>
                    <div className="text-right">
                      <p className="text-amber-400 font-semibold">
                        {simResult.impactDay30}GB
                      </p>
                      <p className="text-amber-600 text-xs">
                        (was {predictions.day_30}GB)
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommendation */}
              {Number(simResult.newUsagePercent) > 80 ? (
                <div className="bg-orange-900/20 border border-orange-700/50 rounded p-3 text-orange-200 text-sm">
                  ⚠️ Still at warning level. Consider freeing more space.
                </div>
              ) : (
                <div className="bg-green-900/20 border border-green-700/50 rounded p-3 text-green-200 text-sm">
                  ✓ Storage will be at healthy levels. Safe to proceed!
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full min-h-[300px]">
              <div className="text-center">
                <Zap className="w-12 h-12 text-slate-500 mx-auto mb-3 opacity-50" />
                <p className="text-slate-400">
                  Run simulation to see impact
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
