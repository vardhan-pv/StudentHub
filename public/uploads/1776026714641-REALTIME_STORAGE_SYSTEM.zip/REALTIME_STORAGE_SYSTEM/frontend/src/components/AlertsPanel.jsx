import React, { useState } from 'react';
import { AlertCircle, AlertTriangle, Info, X } from 'lucide-react';

export default function AlertsPanel({ alerts }) {
  const [dismissedAlerts, setDismissedAlerts] = useState(new Set());

  const dismissAlert = (id) => {
    setDismissedAlerts(new Set([...dismissedAlerts, id]));
  };

  const visibleAlerts = alerts.filter(a => !dismissedAlerts.has(a.id));

  const getSeverityConfig = (severity) => {
    switch (severity) {
      case 'critical':
        return {
          bg: 'bg-red-900/20',
          border: 'border-red-700/50',
          icon: AlertCircle,
          textColor: 'text-red-200',
          badgeBg: 'bg-red-900',
          badgeText: 'text-red-200',
        };
      case 'warning':
        return {
          bg: 'bg-orange-900/20',
          border: 'border-orange-700/50',
          icon: AlertTriangle,
          textColor: 'text-orange-200',
          badgeBg: 'bg-orange-900',
          badgeText: 'text-orange-200',
        };
      default:
        return {
          bg: 'bg-blue-900/20',
          border: 'border-blue-700/50',
          icon: Info,
          textColor: 'text-blue-200',
          badgeBg: 'bg-blue-900',
          badgeText: 'text-blue-200',
        };
    }
  };

  return (
    <div className="bg-slate-800 rounded-lg border border-slate-700 p-6">
      <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <AlertCircle className="w-5 h-5" />
        Alerts ({visibleAlerts.length})
      </h2>

      {visibleAlerts.length === 0 ? (
        <div className="text-center py-8">
          <div className="text-green-400 text-sm mb-2">✓ No active alerts</div>
          <p className="text-slate-400 text-sm">Your storage is in good shape!</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[400px] overflow-y-auto">
          {visibleAlerts.map((alert) => {
            const config = getSeverityConfig(alert.severity);
            const IconComponent = config.icon;

            return (
              <div
                key={alert.id}
                className={`${config.bg} ${config.border} border rounded-lg p-4 ${config.textColor} animate-in fade-in slide-in-from-left-2 duration-300`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <IconComponent className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{alert.title}</h3>
                        <span className={`${config.badgeBg} ${config.badgeText} text-xs px-2 py-0.5 rounded`}>
                          {alert.severity.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm opacity-90 mb-2">{alert.message}</p>

                      {alert.recommendations && alert.recommendations.length > 0 && (
                        <div className="text-xs mt-2 opacity-75">
                          <p className="font-semibold mb-1">Quick fixes:</p>
                          <ul className="list-disc list-inside space-y-0.5">
                            {alert.recommendations.slice(0, 3).map((rec, idx) => (
                              <li key={idx}>{rec}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => dismissAlert(alert.id)}
                    className="ml-2 p-1 hover:bg-white/10 rounded transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Alert Stats */}
      {visibleAlerts.length > 0 && (
        <div className="mt-4 pt-4 border-t border-slate-700">
          <div className="text-xs text-slate-400 space-y-1">
            <div>
              Critical: {visibleAlerts.filter(a => a.severity === 'critical').length}
            </div>
            <div>
              Warnings: {visibleAlerts.filter(a => a.severity === 'warning').length}
            </div>
            <div>
              Info: {visibleAlerts.filter(a => a.severity === 'info').length}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
