import React, { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';

export default function StorageMonitor({ storage }) {
  const [prevUsed, setPrevUsed] = useState(storage.used_gb);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    if (Math.abs(storage.used_gb - prevUsed) > 0.05) {
      setAnimate(true);
      setTimeout(() => setAnimate(false), 500);
      setPrevUsed(storage.used_gb);
    }
  }, [storage.used_gb, prevUsed]);

  const usagePercent = storage.usage_percent;
  const statusColor =
    usagePercent >= 90
      ? 'from-red-500 to-red-600'
      : usagePercent >= 80
      ? 'from-orange-500 to-orange-600'
      : usagePercent >= 70
      ? 'from-yellow-500 to-yellow-600'
      : 'from-green-500 to-green-600';

  const statusBg =
    usagePercent >= 90
      ? 'bg-red-900/20'
      : usagePercent >= 80
      ? 'bg-orange-900/20'
      : usagePercent >= 70
      ? 'bg-yellow-900/20'
      : 'bg-green-900/20';

  const StatusIcon =
    usagePercent >= 90
      ? AlertCircle
      : usagePercent >= 80
      ? AlertTriangle
      : CheckCircle;

  return (
    <div className={`bg-slate-800 rounded-lg border border-slate-700 p-6 ${statusBg}`}>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-white">Storage Usage</h2>
        <StatusIcon
          className={`w-6 h-6 ${
            usagePercent >= 90
              ? 'text-red-400'
              : usagePercent >= 80
              ? 'text-orange-400'
              : usagePercent >= 70
              ? 'text-yellow-400'
              : 'text-green-400'
          }`}
        />
      </div>

      {/* Main Storage Display */}
      <div className="mb-6">
        <div className="flex items-baseline gap-2 mb-2">
          <span className={`text-4xl font-bold ${animate ? 'scale-110' : 'scale-100'} transition-transform`}>
            {storage.used_gb.toFixed(1)}
          </span>
          <span className="text-2xl text-slate-400">/ {storage.total_gb}GB</span>
        </div>
        <p className="text-slate-400 text-sm">
          {storage.free_gb.toFixed(1)}GB free
        </p>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-semibold text-slate-300">Usage</span>
          <span className={`text-lg font-bold ${
            usagePercent >= 90
              ? 'text-red-400'
              : usagePercent >= 80
              ? 'text-orange-400'
              : usagePercent >= 70
              ? 'text-yellow-400'
              : 'text-green-400'
          }`}>
            {usagePercent.toFixed(1)}%
          </span>
        </div>

        {/* Animated Progress Bar */}
        <div className="w-full bg-slate-700 rounded-full h-4 overflow-hidden">
          <div
            className={`bg-gradient-to-r ${statusColor} h-4 rounded-full transition-all duration-500 shadow-lg shadow-blue-500/50`}
            style={{ width: `${Math.min(usagePercent, 100)}%` }}
          />
        </div>

        {/* Threshold Markers */}
        <div className="flex justify-between text-xs text-slate-500 mt-2">
          <span>0GB</span>
          <span className="text-yellow-600">80%</span>
          <span className="text-orange-600">90%</span>
          <span>{storage.total_gb}GB</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Used</p>
          <p className="text-white font-semibold">{storage.used_gb.toFixed(2)}GB</p>
        </div>
        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Free</p>
          <p className="text-white font-semibold">{storage.free_gb.toFixed(2)}GB</p>
        </div>
        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Daily Growth</p>
          <p className="text-white font-semibold">{storage.daily_growth_mb}MB</p>
        </div>
        <div className="bg-slate-700/50 rounded p-3 border border-slate-600/50">
          <p className="text-slate-400 text-xs mb-1">Status</p>
          <p className={`font-semibold capitalize ${
            usagePercent >= 90
              ? 'text-red-400'
              : usagePercent >= 80
              ? 'text-orange-400'
              : usagePercent >= 70
              ? 'text-yellow-400'
              : 'text-green-400'
          }`}>
            {storage.status}
          </p>
        </div>
      </div>

      {/* Alert Messages */}
      {usagePercent >= 90 && (
        <div className="mt-4 p-3 bg-red-900/30 border border-red-700/50 rounded text-red-200 text-sm">
          🚨 Critical: Immediate storage management required!
        </div>
      )}
      {usagePercent >= 80 && usagePercent < 90 && (
        <div className="mt-4 p-3 bg-orange-900/30 border border-orange-700/50 rounded text-orange-200 text-sm">
          ⚠️ Warning: Consider freeing up space soon.
        </div>
      )}
      {usagePercent >= 70 && usagePercent < 80 && (
        <div className="mt-4 p-3 bg-yellow-900/30 border border-yellow-700/50 rounded text-yellow-200 text-sm">
          ⚡ Caution: Monitor storage usage.
        </div>
      )}
    </div>
  );
}
