"""
Time-Series Utilities
Helper functions for time-series data management
"""

from datetime import datetime, timedelta
from typing import List, Dict
import numpy as np

class TimeSeriesBuffer:
    """Circular buffer for time-series data with statistical functions"""
    
    def __init__(self, max_points: int = 1440):  # 24 hours at 1-min intervals
        self.max_points = max_points
        self.data: List[Dict] = []
    
    def add_point(self, data_point: Dict):
        """Add a new data point to the buffer"""
        point = {
            **data_point,
            "timestamp": datetime.now().isoformat()
        }
        
        self.data.append(point)
        
        # Keep only max_points
        if len(self.data) > self.max_points:
            self.data = self.data[-self.max_points:]
    
    def get_data(self, limit: int = None) -> List[Dict]:
        """Get data points"""
        if limit:
            return self.data[-limit:]
        return self.data
    
    def get_latest(self) -> Dict:
        """Get the most recent data point"""
        return self.data[-1] if self.data else None
    
    def get_point_at_time(self, minutes_ago: int) -> Dict:
        """Get data point from N minutes ago"""
        if minutes_ago * 12 > len(self.data):  # 12 updates per minute
            return self.data[0] if self.data else None
        return self.data[-(minutes_ago * 12)] if len(self.data) >= minutes_ago * 12 else self.data[0]
    
    def get_average(self, minutes: int = 60, key: str = 'used_gb') -> float:
        """Get average value over time period"""
        points_needed = minutes * 12  # 12 updates per minute
        
        if len(self.data) < points_needed:
            points_needed = len(self.data)
        
        if points_needed == 0:
            return 0
        
        recent_data = self.data[-points_needed:]
        values = [p.get(key, 0) for p in recent_data]
        
        return np.mean(values) if values else 0
    
    def get_max(self, minutes: int = 60, key: str = 'used_gb') -> float:
        """Get maximum value over time period"""
        points_needed = minutes * 12
        
        if len(self.data) < points_needed:
            points_needed = len(self.data)
        
        if points_needed == 0:
            return 0
        
        recent_data = self.data[-points_needed:]
        values = [p.get(key, 0) for p in recent_data]
        
        return max(values) if values else 0
    
    def get_min(self, minutes: int = 60, key: str = 'used_gb') -> float:
        """Get minimum value over time period"""
        points_needed = minutes * 12
        
        if len(self.data) < points_needed:
            points_needed = len(self.data)
        
        if points_needed == 0:
            return 0
        
        recent_data = self.data[-points_needed:]
        values = [p.get(key, 0) for p in recent_data]
        
        return min(values) if values else 0
    
    def get_trend(self) -> str:
        """Determine if trend is increasing, decreasing, or stable"""
        if len(self.data) < 2:
            return "insufficient_data"
        
        # Compare last 10 with previous 10 points
        if len(self.data) < 20:
            recent = self.data[-len(self.data)//2:]
            older = self.data[:len(self.data)//2]
        else:
            recent = self.data[-10:]
            older = self.data[-20:-10]
        
        avg_recent = np.mean([p.get('used_gb', 0) for p in recent])
        avg_older = np.mean([p.get('used_gb', 0) for p in older])
        
        change_percent = ((avg_recent - avg_older) / avg_older * 100) if avg_older > 0 else 0
        
        if change_percent > 2:
            return "increasing"
        elif change_percent < -2:
            return "decreasing"
        else:
            return "stable"
    
    def get_daily_growth(self) -> float:
        """Get estimated daily growth rate"""
        if len(self.data) < 2:
            return 0
        
        # Get data from last 24 hours
        points_in_24h = 24 * 12  # 12 updates per hour
        
        if len(self.data) < points_in_24h:
            start_idx = 0
        else:
            start_idx = -points_in_24h
        
        start_value = self.data[start_idx].get('used_gb', 0)
        end_value = self.data[-1].get('used_gb', 0)
        
        return round(end_value - start_value, 2)
    
    def get_volatility(self, minutes: int = 60) -> float:
        """Get volatility (standard deviation) of storage usage"""
        points_needed = minutes * 12
        
        if len(self.data) < points_needed:
            points_needed = len(self.data)
        
        if points_needed == 0:
            return 0
        
        recent_data = self.data[-points_needed:]
        values = [p.get('used_gb', 0) for p in recent_data]
        
        return np.std(values) if len(values) > 1 else 0
    
    def get_statistics(self, minutes: int = 1440) -> Dict:
        """Get comprehensive statistics"""
        points_needed = minutes * 12
        
        if len(self.data) < points_needed:
            points_needed = len(self.data)
        
        if points_needed == 0:
            return {}
        
        recent_data = self.data[-points_needed:]
        values = [p.get('used_gb', 0) for p in recent_data]
        
        if not values:
            return {}
        
        sorted_values = sorted(values)
        
        return {
            "count": len(values),
            "mean": round(np.mean(values), 2),
            "median": round(np.median(values), 2),
            "std_dev": round(np.std(values), 2),
            "min": round(min(values), 2),
            "max": round(max(values), 2),
            "range": round(max(values) - min(values), 2),
            "q1": round(sorted_values[len(sorted_values)//4], 2),
            "q3": round(sorted_values[3*len(sorted_values)//4], 2),
            "trend": self.get_trend(),
            "time_period_minutes": minutes
        }
    
    def get_change_over_time(self, minutes: int) -> Dict:
        """Get change statistics over a time period"""
        if len(self.data) < 2:
            return {"change_gb": 0, "change_percent": 0}
        
        points_needed = minutes * 12
        
        if len(self.data) < points_needed:
            start_idx = 0
        else:
            start_idx = -points_needed
        
        start_value = self.data[start_idx].get('used_gb', 0)
        end_value = self.data[-1].get('used_gb', 0)
        
        change_gb = end_value - start_value
        change_percent = (change_gb / start_value * 100) if start_value > 0 else 0
        
        return {
            "change_gb": round(change_gb, 2),
            "change_percent": round(change_percent, 1),
            "time_period_minutes": minutes,
            "direction": "increasing" if change_gb > 0 else "decreasing" if change_gb < 0 else "stable"
        }
    
    def clear(self):
        """Clear all data"""
        self.data = []
    
    def get_size_mb(self) -> float:
        """Estimate memory usage of buffer in MB"""
        # Rough estimate: ~500 bytes per data point
        return (len(self.data) * 500) / (1024 * 1024)
