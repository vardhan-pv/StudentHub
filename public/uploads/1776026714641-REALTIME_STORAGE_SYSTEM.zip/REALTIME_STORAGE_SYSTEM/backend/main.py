"""
Real-Time Mobile Storage Intelligence System
FastAPI Backend with WebSocket Support
"""

from fastapi import FastAPI, WebSocket, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Set

from services.storage_monitor import StorageMonitor
from services.websocket_manager import WebSocketManager
from models.storage_predictor import StoragePredictionModel
from models.alert_engine import AlertEngine
from services.recommendation_engine import RecommendationEngine
from utils.time_series import TimeSeriesBuffer

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Real-Time Storage Intelligence API",
    description="AI-powered mobile storage monitoring and prediction system",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# GLOBAL STATE
# ============================================================

class AppState:
    def __init__(self):
        self.websocket_manager = WebSocketManager()
        self.storage_monitor = StorageMonitor()
        self.predictor = StoragePredictionModel()
        self.alert_engine = AlertEngine()
        self.recommendation_engine = RecommendationEngine()
        self.time_series_buffer = TimeSeriesBuffer(max_points=1440)  # 24h @ 1min intervals
        self.is_monitoring = False
        self.monitoring_task = None

app_state = AppState()

# ============================================================
# STARTUP & SHUTDOWN EVENTS
# ============================================================

@app.on_event("startup")
async def startup_event():
    """Initialize system on startup"""
    logger.info("🚀 Storage Intelligence System starting...")
    app_state.is_monitoring = True
    app_state.monitoring_task = asyncio.create_task(continuous_monitoring())
    logger.info("✅ System ready for connections")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("🛑 Shutting down...")
    app_state.is_monitoring = False
    if app_state.monitoring_task:
        app_state.monitoring_task.cancel()

# ============================================================
# BACKGROUND TASKS
# ============================================================

async def continuous_monitoring():
    """
    Continuous monitoring loop
    Generates storage data, updates predictions, checks alerts
    """
    logger.info("📊 Starting continuous monitoring loop...")
    
    while app_state.is_monitoring:
        try:
            # 1. Get current storage metrics
            storage_data = app_state.storage_monitor.get_current_storage()
            
            # 2. Add to time-series buffer
            app_state.time_series_buffer.add_point(storage_data)
            
            # 3. Update prediction model
            predictions = app_state.predictor.predict(
                app_state.time_series_buffer.get_data(),
                days_ahead=[7, 15, 30]
            )
            
            # 4. Check for alerts
            alerts = app_state.alert_engine.check_alerts(
                storage_data,
                predictions,
                app_state.time_series_buffer.get_data()
            )
            
            # 5. Generate recommendations
            recommendations = app_state.recommendation_engine.generate_recommendations(
                storage_data,
                predictions,
                app_state.time_series_buffer.get_data()
            )
            
            # 6. Build broadcast message
            broadcast_data = {
                "timestamp": datetime.now().isoformat(),
                "storage": storage_data,
                "predictions": predictions,
                "alerts": alerts,
                "recommendations": recommendations,
                "trend": app_state.time_series_buffer.get_trend()
            }
            
            # 7. Broadcast to all connected clients
            await app_state.websocket_manager.broadcast(broadcast_data)
            
            # Log brief status
            logger.info(
                f"📡 Update: Used={storage_data['used_gb']:.1f}GB, "
                f"Free={storage_data['free_gb']:.1f}GB, "
                f"Alerts={len(alerts)}, Clients={len(app_state.websocket_manager.active_connections)}"
            )
            
            # Wait before next update (2 seconds for demo, adjust as needed)
            await asyncio.sleep(2)
            
        except asyncio.CancelledError:
            logger.info("Monitoring loop cancelled")
            break
        except Exception as e:
            logger.error(f"❌ Error in monitoring loop: {str(e)}")
            await asyncio.sleep(5)  # Backoff on error

# ============================================================
# REST API ENDPOINTS
# ============================================================

@app.get("/api/health")
async def health_check():
    """System health check"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "monitoring": app_state.is_monitoring,
        "connected_clients": len(app_state.websocket_manager.active_connections)
    }

@app.get("/api/storage/current")
async def get_current_storage():
    """Get current storage metrics"""
    storage_data = app_state.storage_monitor.get_current_storage()
    return {
        "status": "success",
        "data": storage_data,
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/storage/history")
async def get_storage_history(limit: int = 100):
    """Get historical storage data"""
    history = app_state.time_series_buffer.get_data(limit)
    return {
        "status": "success",
        "data": history,
        "count": len(history)
    }

@app.get("/api/predictions")
async def get_predictions(days_ahead: int = 30):
    """Get storage predictions"""
    data = app_state.time_series_buffer.get_data()
    if not data:
        raise HTTPException(status_code=400, detail="Not enough data for predictions")
    
    predictions = app_state.predictor.predict(
        data,
        days_ahead=[7, 15, 30] if days_ahead >= 30 else [days_ahead]
    )
    return {
        "status": "success",
        "data": predictions,
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/alerts")
async def get_alerts(limit: int = 50):
    """Get alert history"""
    alerts = app_state.alert_engine.get_alert_history(limit)
    return {
        "status": "success",
        "data": alerts,
        "count": len(alerts)
    }

@app.get("/api/recommendations")
async def get_recommendations():
    """Get AI recommendations"""
    storage_data = app_state.storage_monitor.get_current_storage()
    predictions = app_state.predictor.predict(
        app_state.time_series_buffer.get_data(),
        days_ahead=[7]
    )
    recommendations = app_state.recommendation_engine.generate_recommendations(
        storage_data,
        predictions,
        app_state.time_series_buffer.get_data()
    )
    return {
        "status": "success",
        "data": recommendations,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/what-if/delete-app")
async def simulate_app_deletion(app_name: str, size_mb: float):
    """Simulate deleting an app and predict storage impact"""
    current_storage = app_state.storage_monitor.get_current_storage()
    
    # Simulate deletion
    simulated_storage = current_storage.copy()
    simulated_storage["used_gb"] -= (size_mb / 1024)
    simulated_storage["free_gb"] += (size_mb / 1024)
    simulated_storage["usage_percent"] = (simulated_storage["used_gb"] / simulated_storage["total_gb"]) * 100
    
    # Get prediction with simulated storage
    predictions = app_state.predictor.predict(
        app_state.time_series_buffer.get_data(),
        days_ahead=[7, 15, 30]
    )
    
    # Adjust predictions based on freed space
    freed_space = size_mb / 1024
    
    return {
        "status": "success",
        "app_name": app_name,
        "freed_space_gb": freed_space,
        "current_state": current_storage,
        "simulated_state": simulated_storage,
        "impact_on_predictions": {
            f"day_{days}": pred - freed_space 
            for days, pred in predictions.items()
        },
        "recommendation": "safe_to_delete" if freed_space > 0.5 else "minimal_impact"
    }

@app.post("/api/config/alert-threshold")
async def set_alert_threshold(warning_percent: int, critical_percent: int):
    """Configure alert thresholds"""
    if not (0 < warning_percent < critical_percent <= 100):
        raise HTTPException(status_code=400, detail="Invalid threshold values")
    
    app_state.alert_engine.set_thresholds(warning_percent, critical_percent)
    return {
        "status": "success",
        "warning_threshold": warning_percent,
        "critical_threshold": critical_percent
    }

@app.get("/api/stats/system")
async def get_system_stats():
    """Get overall system statistics"""
    data = app_state.time_series_buffer.get_data()
    if not data:
        raise HTTPException(status_code=400, detail="Not enough data")
    
    return {
        "status": "success",
        "data": {
            "total_data_points": len(data),
            "uptime_minutes": (datetime.now() - app_state.storage_monitor.start_time).total_seconds() / 60,
            "avg_daily_growth_gb": app_state.time_series_buffer.get_daily_growth(),
            "prediction_accuracy": "N/A",  # Calculate based on historical predictions
            "connected_clients": len(app_state.websocket_manager.active_connections),
            "monitoring_status": "active" if app_state.is_monitoring else "inactive"
        }
    }

# ============================================================
# WEBSOCKET ENDPOINT
# ============================================================

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time updates
    
    Events sent to client:
    - storage_update: Current storage metrics
    - prediction_update: Storage predictions
    - alert: New alert triggered
    - recommendation: New recommendation
    - history: Historical data
    """
    await app_state.websocket_manager.connect(websocket)
    
    try:
        logger.info(f"🔌 New WebSocket connection. Total: {len(app_state.websocket_manager.active_connections)}")
        
        # Send initial data to client
        storage_data = app_state.storage_monitor.get_current_storage()
        history = app_state.time_series_buffer.get_data(50)
        predictions = app_state.predictor.predict(
            app_state.time_series_buffer.get_data(),
            days_ahead=[7, 15, 30]
        )
        
        initial_message = {
            "event": "initial_data",
            "storage": storage_data,
            "history": history,
            "predictions": predictions,
            "timestamp": datetime.now().isoformat()
        }
        
        await websocket.send_json(initial_message)
        
        # Keep connection alive and listen for client messages
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle different message types from client
            if message.get("type") == "ping":
                await websocket.send_json({"event": "pong", "timestamp": datetime.now().isoformat()})
            
            elif message.get("type") == "request_simulation":
                app_name = message.get("app_name")
                size_mb = message.get("size_mb", 100)
                # Simulate and send back
                sim_result = {
                    "event": "simulation_result",
                    "app_name": app_name,
                    "freed_space_gb": size_mb / 1024,
                    "impact": "positive"
                }
                await websocket.send_json(sim_result)
            
    except Exception as e:
        logger.error(f"❌ WebSocket error: {str(e)}")
    finally:
        await app_state.websocket_manager.disconnect(websocket)
        logger.info(f"🔌 Client disconnected. Remaining: {len(app_state.websocket_manager.active_connections)}")

# ============================================================
# ROOT ENDPOINT
# ============================================================

@app.get("/")
async def root():
    """API info"""
    return {
        "name": "Real-Time Storage Intelligence System",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
        "ws_endpoint": "ws://localhost:8000/ws"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
