"""
Configuration Module
Settings for the storage intelligence system
"""

from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    """Application settings"""
    
    # Server
    APP_NAME: str = "Real-Time Storage Intelligence"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Storage
    TOTAL_STORAGE_GB: float = 128.0
    INITIAL_USED_GB: float = 45.0
    
    # Alerts
    WARNING_THRESHOLD_PERCENT: int = 80
    CRITICAL_THRESHOLD_PERCENT: int = 90
    SPIKE_DETECTION_THRESHOLD_PERCENT: int = 15
    MIN_SPIKE_SIZE_MB: float = 100.0
    
    # WebSocket
    WS_UPDATE_INTERVAL_SECONDS: int = 2
    WS_MAX_CONNECTIONS: int = 100
    
    # Data
    TIME_SERIES_MAX_POINTS: int = 1440  # 24 hours
    ALERT_HISTORY_LIMIT: int = 1000
    RECOMMENDATION_LIMIT: int = 500
    
    # Prediction
    MIN_DATA_POINTS_FOR_PREDICTION: int = 5
    PREDICTION_DAYS: list = [7, 15, 30]
    
    # CORS
    CORS_ORIGINS: list = ["*"]
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Global settings instance
settings = Settings()
