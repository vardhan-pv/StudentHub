"""
Storage Prediction Model
Time-series forecasting for storage usage prediction
Uses simple linear/polynomial regression and exponential smoothing
"""

from datetime import datetime, timedelta
import numpy as np
from typing import List, Dict, Union

class StoragePredictionModel:
    """Predict future storage usage"""
    
    def __init__(self):
        self.min_data_points = 5
        self.alpha = 0.3  # Exponential smoothing factor
        self.poly_degree = 2  # Polynomial regression degree
    
    def predict(
        self,
        historical_data: List[Dict],
        days_ahead: List[int] = None
    ) -> Dict[str, float]:
        """
        Predict storage usage for specific days ahead
        
        Args:
            historical_data: List of dicts with 'used_gb' and 'timestamp'
            days_ahead: List of days to predict (e.g., [7, 15, 30])
        
        Returns:
            dict: Predictions {f"day_{days}": predicted_gb}
        """
        if days_ahead is None:
            days_ahead = [7, 15, 30]
        
        if not historical_data or len(historical_data) < self.min_data_points:
            return {f"day_{days}": 0.0 for days in days_ahead}
        
        # Extract time-series data
        timestamps = []
        values = []
        
        for point in historical_data[-100:]:  # Use last 100 points
            try:
                if isinstance(point, dict):
                    timestamps.append(datetime.fromisoformat(point['timestamp']))
                    values.append(point['used_gb'])
            except (KeyError, ValueError):
                continue
        
        if len(values) < self.min_data_points:
            return {f"day_{days}": values[-1] if values else 0 for days in days_ahead}
        
        # Calculate predictions using multiple methods
        predictions = {}
        
        for days in days_ahead:
            # Method 1: Linear regression with time decay
            pred_linear = self._linear_prediction(values, days)
            
            # Method 2: Exponential smoothing
            pred_exp = self._exponential_smoothing(values, days)
            
            # Method 3: Growth rate-based
            pred_growth = self._growth_rate_prediction(values, days)
            
            # Combine predictions with weighted average
            final_prediction = (
                pred_linear * 0.4 +
                pred_exp * 0.35 +
                pred_growth * 0.25
            )
            
            # Bounds check
            final_prediction = max(final_prediction, values[-1])  # Can't decrease
            final_prediction = min(final_prediction, 128.0)  # Assuming 128GB device
            
            predictions[f"day_{days}"] = round(final_prediction, 2)
        
        return predictions
    
    def _linear_prediction(self, values: List[float], days: int) -> float:
        """Linear regression prediction"""
        if len(values) < 2:
            return values[-1]
        
        x = np.arange(len(values))
        y = np.array(values)
        
        # Simple linear regression
        slope = (np.sum(x * y) - len(values) * np.mean(x) * np.mean(y)) / \
                (np.sum(x**2) - len(values) * np.mean(x)**2)
        intercept = np.mean(y) - slope * np.mean(x)
        
        # Predict for future point
        future_x = len(values) + days * 12  # 12 updates per day (assuming 2-sec intervals)
        prediction = slope * future_x + intercept
        
        return prediction
    
    def _exponential_smoothing(self, values: List[float], days: int) -> float:
        """Exponential smoothing prediction"""
        if len(values) < 1:
            return values[-1] if values else 0
        
        # Apply exponential smoothing
        smoothed = [values[0]]
        
        for value in values[1:]:
            smoothed_value = self.alpha * value + (1 - self.alpha) * smoothed[-1]
            smoothed.append(smoothed_value)
        
        # Assume trend continues
        recent_trend = (smoothed[-1] - smoothed[-5]) / 5 if len(smoothed) >= 5 else 0
        
        # Scale trend by days
        prediction = smoothed[-1] + (recent_trend * days * 12)
        
        return prediction
    
    def _growth_rate_prediction(self, values: List[float], days: int) -> float:
        """Growth rate-based prediction"""
        if len(values) < 2:
            return values[-1]
        
        # Calculate daily growth rate from recent data (last 20 points)
        recent_values = values[-min(20, len(values)):]
        
        if len(recent_values) < 2:
            return values[-1]
        
        # Growth per update
        growth_per_update = (recent_values[-1] - recent_values[0]) / len(recent_values)
        
        # Predict for days ahead
        updates_ahead = days * 12  # 12 updates per day
        prediction = values[-1] + (growth_per_update * updates_ahead)
        
        return prediction
    
    def predict_exhaustion_date(
        self,
        historical_data: List[Dict],
        total_gb: float = 128.0,
        warning_threshold: float = 0.9
    ) -> Dict[str, Union[str, float, bool]]:
        """
        Predict when storage will be full
        
        Args:
            historical_data: Historical storage data
            total_gb: Total storage capacity
            warning_threshold: Threshold percentage (0.9 = 90%)
        
        Returns:
            dict: Exhaustion info
        """
        if not historical_data or len(historical_data) < 2:
            return {
                "exhaustion_date": None,
                "days_until_full": None,
                "will_exhaust": False
            }
        
        values = [p['used_gb'] for p in historical_data if 'used_gb' in p]
        
        if len(values) < 2:
            return {
                "exhaustion_date": None,
                "days_until_full": None,
                "will_exhaust": False
            }
        
        # Calculate growth rate
        growth_rate = (values[-1] - values[0]) / max(len(values), 1)
        
        if growth_rate <= 0:
            return {
                "exhaustion_date": None,
                "days_until_full": None,
                "will_exhaust": False,
                "trend": "decreasing"
            }
        
        # Days to reach threshold
        threshold_gb = total_gb * warning_threshold
        remaining_space = threshold_gb - values[-1]
        
        if remaining_space <= 0:
            days_until = 0
        else:
            # Assuming 12 updates per day
            days_until = remaining_space / (growth_rate * 12)
        
        exhaustion_date = datetime.now() + timedelta(days=days_until)
        
        return {
            "current_used_gb": round(values[-1], 2),
            "threshold_gb": round(threshold_gb, 2),
            "remaining_space_gb": round(remaining_space, 2),
            "growth_rate_per_update_gb": round(growth_rate, 4),
            "growth_rate_daily_mb": round(growth_rate * 12 * 1024, 1),
            "days_until_full": max(0, round(days_until, 1)),
            "exhaustion_date": exhaustion_date.isoformat() if days_until > 0 else "Already exceeded",
            "will_exhaust_in_30_days": days_until <= 30 and days_until > 0,
            "risk_level": self._calculate_risk_level(days_until)
        }
    
    def _calculate_risk_level(self, days_until: float) -> str:
        """Calculate risk level based on days until exhaustion"""
        if days_until <= 0:
            return "critical"
        elif days_until <= 3:
            return "high"
        elif days_until <= 7:
            return "medium"
        elif days_until <= 14:
            return "low"
        else:
            return "minimal"
    
    def get_prediction_confidence(
        self,
        historical_data: List[Dict]
    ) -> Dict[str, float]:
        """
        Calculate confidence in predictions based on data quality
        
        Returns:
            dict: Confidence scores for different prediction ranges
        """
        if not historical_data or len(historical_data) < 5:
            return {
                "short_term_7d": 0.5,
                "medium_term_15d": 0.3,
                "long_term_30d": 0.2
            }
        
        values = [p['used_gb'] for p in historical_data if 'used_gb' in p]
        
        # Calculate variance (lower is better)
        if len(values) > 1:
            variance = np.var(values)
            # Normalize to 0-1 scale
            stability_score = max(0, 1 - (variance / np.mean(values)))
        else:
            stability_score = 0.5
        
        # Calculate data density (more points = more confidence)
        data_density_score = min(1.0, len(values) / 100)
        
        # Combined confidence
        confidence_factor = (stability_score * 0.6 + data_density_score * 0.4)
        
        return {
            "short_term_7d": round(min(1.0, confidence_factor * 1.2), 2),
            "medium_term_15d": round(confidence_factor, 2),
            "long_term_30d": round(max(0.2, confidence_factor * 0.7), 2),
            "data_quality_score": round(confidence_factor, 2)
        }
