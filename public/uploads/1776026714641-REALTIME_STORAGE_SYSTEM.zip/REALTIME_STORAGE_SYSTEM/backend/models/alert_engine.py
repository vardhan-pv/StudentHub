"""
Alert Engine
Detects and generates alerts for storage-related issues
"""

from datetime import datetime, timedelta
from typing import List, Dict
import logging

logger = logging.getLogger(__name__)

class AlertEngine:
    """Generate and manage storage alerts"""
    
    def __init__(self):
        self.warning_threshold = 80  # %
        self.critical_threshold = 90  # %
        self.spike_detection_threshold = 15  # % increase in 24h
        self.min_spike_size_mb = 100  # Minimum spike to alert
        
        self.alert_history: List[Dict] = []
        self.last_alerts: Dict[str, datetime] = {}  # Prevent alert spam
        self.alert_cooldown_minutes = 5  # Minimum time between same alerts
    
    def check_alerts(
        self,
        current_storage: Dict,
        predictions: Dict,
        historical_data: List[Dict]
    ) -> List[Dict]:
        """
        Check for all types of alerts
        
        Returns:
            List of active alerts
        """
        current_alerts = []
        
        # 1. Threshold-based alerts
        threshold_alerts = self._check_threshold_alerts(current_storage)
        current_alerts.extend(threshold_alerts)
        
        # 2. Spike detection
        spike_alerts = self._detect_spikes(historical_data)
        current_alerts.extend(spike_alerts)
        
        # 3. Rapid exhaustion alert
        exhaustion_alerts = self._check_exhaustion_risk(predictions, historical_data)
        current_alerts.extend(exhaustion_alerts)
        
        # 4. Category-specific alerts
        category_alerts = self._check_category_alerts(current_storage)
        current_alerts.extend(category_alerts)
        
        # Filter duplicates and apply cooldown
        unique_alerts = self._filter_duplicate_alerts(current_alerts)
        
        # Add to history
        for alert in unique_alerts:
            self.alert_history.append(alert)
        
        # Keep only recent alerts (last 1000)
        self.alert_history = self.alert_history[-1000:]
        
        return unique_alerts
    
    def _check_threshold_alerts(self, storage_data: Dict) -> List[Dict]:
        """Check if storage exceeds warning/critical thresholds"""
        alerts = []
        usage_percent = storage_data['usage_percent']
        
        # Critical alert
        if usage_percent >= self.critical_threshold:
            alert = {
                "id": f"critical_{datetime.now().timestamp()}",
                "type": "critical_threshold",
                "severity": "critical",
                "title": "🔴 CRITICAL: Storage Nearly Full",
                "message": f"Storage usage at {usage_percent:.1f}%. Immediate action required!",
                "usage_percent": usage_percent,
                "threshold": self.critical_threshold,
                "icon": "🚨",
                "timestamp": datetime.now().isoformat(),
                "recommendations": [
                    "Delete unused apps",
                    "Clear cache files",
                    "Remove old media files",
                    "Uninstall large games"
                ],
                "action_required": True
            }
            alerts.append(alert)
        
        # Warning alert
        elif usage_percent >= self.warning_threshold:
            alert = {
                "id": f"warning_{datetime.now().timestamp()}",
                "type": "warning_threshold",
                "severity": "warning",
                "title": "⚠️ WARNING: Storage Running Low",
                "message": f"Storage usage at {usage_percent:.1f}%. Consider freeing space.",
                "usage_percent": usage_percent,
                "threshold": self.warning_threshold,
                "icon": "⚠️",
                "timestamp": datetime.now().isoformat(),
                "recommendations": [
                    "Review large files",
                    "Clear app caches",
                    "Move photos to cloud"
                ],
                "action_required": True
            }
            alerts.append(alert)
        
        return alerts
    
    def _detect_spikes(self, historical_data: List[Dict]) -> List[Dict]:
        """Detect sudden spikes in storage usage"""
        alerts = []
        
        if len(historical_data) < 2:
            return alerts
        
        # Get recent data (last 2 hours, assuming 2-sec updates = 3600 points)
        recent_data = historical_data[-3600:]
        
        if len(recent_data) < 100:
            return alerts
        
        current_usage = recent_data[-1]['used_gb']
        usage_1h_ago = recent_data[0]['used_gb']
        
        # Calculate spike
        change_gb = current_usage - usage_1h_ago
        change_percent = (change_gb / usage_1h_ago * 100) if usage_1h_ago > 0 else 0
        
        # Detect significant spike
        if change_percent >= self.spike_detection_threshold and change_gb >= (self.min_spike_size_mb / 1024):
            alert = {
                "id": f"spike_{datetime.now().timestamp()}",
                "type": "usage_spike",
                "severity": "info",
                "title": "📈 Unusual Storage Activity Detected",
                "message": f"Storage increased by {change_gb:.2f}GB ({change_percent:.1f}%) in the last hour",
                "change_gb": round(change_gb, 2),
                "change_percent": round(change_percent, 1),
                "spike_time_minutes": 60,
                "icon": "📈",
                "timestamp": datetime.now().isoformat(),
                "likely_cause": self._identify_spike_cause(change_gb),
                "recommendations": [
                    "Check recent app installations",
                    "Review photo/video uploads",
                    "Check for large downloads"
                ],
                "action_required": False
            }
            alerts.append(alert)
        
        return alerts
    
    def _check_exhaustion_risk(
        self,
        predictions: Dict,
        historical_data: List[Dict]
    ) -> List[Dict]:
        """Check if storage will be full soon"""
        alerts = []
        
        if not predictions or not historical_data:
            return alerts
        
        # Check 7-day prediction
        day_7_pred = predictions.get('day_7', 0)
        
        # If predicted to reach 95% usage in 7 days
        if day_7_pred > 0:
            predicted_percent = (day_7_pred / 128.0) * 100
            
            if predicted_percent >= 95:
                alert = {
                    "id": f"exhaustion_{datetime.now().timestamp()}",
                    "type": "exhaustion_risk",
                    "severity": "warning",
                    "title": "⏰ Storage Will Be Full Soon",
                    "message": f"At current growth rate, storage will be full in ~7 days ({predicted_percent:.1f}% predicted)",
                    "predicted_usage_day_7_gb": day_7_pred,
                    "predicted_usage_percent_day_7": predicted_percent,
                    "icon": "⏰",
                    "timestamp": datetime.now().isoformat(),
                    "recommendations": [
                        "Clear old media files",
                        "Uninstall unused apps",
                        "Enable cloud backup",
                        "Delete cached data"
                    ],
                    "action_required": True
                }
                alerts.append(alert)
        
        return alerts
    
    def _check_category_alerts(self, storage_data: Dict) -> List[Dict]:
        """Generate alerts based on category-specific issues"""
        alerts = []
        
        categories = storage_data.get('categories', [])
        
        for category in categories:
            # Photos category getting too large
            if category['name'] == 'Photos' and category['size_gb'] > 30:
                alerts.append({
                    "id": f"category_{category['name']}_{datetime.now().timestamp()}",
                    "type": "large_category",
                    "severity": "info",
                    "title": f"📸 Large {category['name']} Folder",
                    "message": f"{category['name']} is using {category['size_gb']:.1f}GB. Consider cloud backup.",
                    "category": category['name'],
                    "size_gb": category['size_gb'],
                    "icon": category.get('icon', '📁'),
                    "timestamp": datetime.now().isoformat(),
                    "action_required": False
                })
            
            # Cache getting large
            if category['name'] == 'Cache' and category['size_gb'] > 5:
                alerts.append({
                    "id": f"category_{category['name']}_{datetime.now().timestamp()}",
                    "type": "large_cache",
                    "severity": "info",
                    "title": "♻️ Large Cache Detected",
                    "message": f"Cache files are using {category['size_gb']:.1f}GB. Safe to clear.",
                    "category": category['name'],
                    "size_gb": category['size_gb'],
                    "icon": "♻️",
                    "timestamp": datetime.now().isoformat(),
                    "recommendations": ["Clear cache to free space"],
                    "action_required": False
                })
        
        return alerts
    
    def _identify_spike_cause(self, change_gb: float) -> str:
        """Identify likely cause of spike"""
        if change_gb > 1.0:
            return "Video download or app installation"
        elif change_gb > 0.5:
            return "Possible app update or photo sync"
        else:
            return "Regular app usage and caching"
    
    def _filter_duplicate_alerts(self, alerts: List[Dict]) -> List[Dict]:
        """Filter out duplicate alerts within cooldown period"""
        filtered = []
        now = datetime.now()
        
        for alert in alerts:
            alert_type = alert.get('type')
            last_alert_time = self.last_alerts.get(alert_type)
            
            # Check cooldown
            if last_alert_time is None or \
               (now - last_alert_time).total_seconds() >= (self.alert_cooldown_minutes * 60):
                filtered.append(alert)
                self.last_alerts[alert_type] = now
        
        return filtered
    
    def set_thresholds(self, warning_percent: int, critical_percent: int):
        """Update alert thresholds"""
        self.warning_threshold = warning_percent
        self.critical_threshold = critical_percent
        logger.info(f"Alert thresholds updated: Warning={warning_percent}%, Critical={critical_percent}%")
    
    def get_alert_history(self, limit: int = 50) -> List[Dict]:
        """Get recent alert history"""
        return self.alert_history[-limit:]
    
    def clear_alert_history(self):
        """Clear alert history"""
        self.alert_history = []
        self.last_alerts = {}
    
    def get_alert_stats(self) -> Dict:
        """Get alert statistics"""
        if not self.alert_history:
            return {
                "total_alerts": 0,
                "critical_count": 0,
                "warning_count": 0,
                "info_count": 0
            }
        
        return {
            "total_alerts": len(self.alert_history),
            "critical_count": sum(1 for a in self.alert_history if a.get('severity') == 'critical'),
            "warning_count": sum(1 for a in self.alert_history if a.get('severity') == 'warning'),
            "info_count": sum(1 for a in self.alert_history if a.get('severity') == 'info'),
            "alert_types": list(set(a.get('type') for a in self.alert_history))
        }
