"""
WebSocket Manager
Handles multiple concurrent WebSocket connections with broadcasting
"""

from fastapi import WebSocket
import json
import logging
from typing import List

logger = logging.getLogger(__name__)

class WebSocketManager:
    """Manage WebSocket connections and broadcasting"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        """Accept a new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"✅ WebSocket connected. Total active: {len(self.active_connections)}")
    
    async def disconnect(self, websocket: WebSocket):
        """Remove a WebSocket connection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"❌ WebSocket disconnected. Remaining: {len(self.active_connections)}")
    
    async def broadcast(self, message: dict):
        """
        Broadcast message to all connected clients
        
        Args:
            message: Dictionary to send as JSON
        """
        if not self.active_connections:
            return
        
        disconnected = []
        
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to connection: {str(e)}")
                disconnected.append(connection)
        
        # Remove dead connections
        for connection in disconnected:
            await self.disconnect(connection)
    
    async def send_personal(self, websocket: WebSocket, message: dict):
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Error sending personal message: {str(e)}")
            await self.disconnect(websocket)
    
    async def broadcast_alert(self, alert: dict):
        """Broadcast alert to all clients"""
        message = {
            "event": "alert",
            "data": alert
        }
        await self.broadcast(message)
    
    async def broadcast_prediction(self, predictions: dict):
        """Broadcast prediction update to all clients"""
        message = {
            "event": "prediction_update",
            "data": predictions
        }
        await self.broadcast(message)
    
    async def broadcast_storage(self, storage_data: dict):
        """Broadcast storage update to all clients"""
        message = {
            "event": "storage_update",
            "data": storage_data
        }
        await self.broadcast(message)
    
    async def broadcast_recommendation(self, recommendation: dict):
        """Broadcast recommendation to all clients"""
        message = {
            "event": "recommendation",
            "data": recommendation
        }
        await self.broadcast(message)
    
    async def broadcast_system_alert(self, alert_type: str, message: str, severity: str = "info"):
        """Broadcast system-level alert"""
        broadcast_message = {
            "event": "system_alert",
            "type": alert_type,
            "message": message,
            "severity": severity  # info, warning, critical
        }
        await self.broadcast(broadcast_message)
    
    def get_connection_count(self) -> int:
        """Get number of active connections"""
        return len(self.active_connections)
