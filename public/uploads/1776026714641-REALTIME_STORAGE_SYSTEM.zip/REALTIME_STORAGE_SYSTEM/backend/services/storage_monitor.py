"""
Storage Monitor Service
Generates realistic real-time storage data with dynamic patterns
"""

import random
from datetime import datetime
import math

class StorageMonitor:
    """Monitor and generate realistic storage metrics"""
    
    def __init__(self, total_gb: float = 128.0):
        self.total_gb = total_gb
        self.current_used_gb = 45.0  # Start at 45GB
        self.start_time = datetime.now()
        
        # Storage patterns
        self.daily_growth = 0.15  # 150MB per day
        self.usage_pattern = "normal"  # normal, heavy, critical
        self.app_categories = {
            "Photos": {"size_gb": 28.5, "growth_rate": 0.05, "icon": "📷"},
            "Videos": {"size_gb": 12.3, "growth_rate": 0.08, "icon": "🎬"},
            "Apps": {"size_gb": 18.7, "growth_rate": 0.02, "icon": "📱"},
            "Documents": {"size_gb": 8.2, "growth_rate": 0.01, "icon": "📄"},
            "Cache": {"size_gb": 6.8, "growth_rate": 0.03, "icon": "♻️"},
            "Other": {"size_gb": 3.5, "growth_rate": 0.01, "icon": "🗂️"}
        }
    
    def get_current_storage(self) -> dict:
        """
        Generate current storage metrics with realistic patterns
        
        Returns:
            dict: Storage metrics including used, free, total, and breakdown
        """
        # Simulate realistic growth patterns
        self._update_storage_usage()
        
        free_gb = self.total_gb - self.current_used_gb
        usage_percent = (self.current_used_gb / self.total_gb) * 100
        
        # Calculate category breakdown
        category_breakdown = []
        for category, info in self.app_categories.items():
            category_breakdown.append({
                "name": category,
                "size_gb": round(info["size_gb"], 2),
                "size_mb": round(info["size_gb"] * 1024, 1),
                "percentage": round((info["size_gb"] / self.current_used_gb) * 100, 1),
                "growth_rate_daily_mb": round(info["growth_rate"] * 150, 1),
                "icon": info["icon"]
            })
        
        # Find largest app category
        largest_category = max(category_breakdown, key=lambda x: x["size_gb"])
        
        return {
            "timestamp": datetime.now().isoformat(),
            "total_gb": round(self.total_gb, 2),
            "used_gb": round(self.current_used_gb, 2),
            "free_gb": round(free_gb, 2),
            "usage_percent": round(usage_percent, 1),
            "status": self._get_storage_status(usage_percent),
            "trend": self._get_trend(),
            "daily_growth_mb": round(self.daily_growth * 150, 1),
            "categories": category_breakdown,
            "largest_category": largest_category["name"],
            "warning_threshold": 80,
            "critical_threshold": 90
        }
    
    def _update_storage_usage(self):
        """
        Update current storage with realistic patterns
        Simulates:
        - Gradual daily growth
        - Random spikes (apps installed, photos added)
        - Pattern-based usage (normal, heavy, critical)
        """
        # Get time-based growth
        minutes_elapsed = (datetime.now() - self.start_time).total_seconds() / 60
        base_growth = (minutes_elapsed / (24 * 60)) * self.daily_growth
        
        # Add randomness (daily fluctuations)
        random_variation = random.gauss(0, 0.05)  # Small random changes
        
        # Simulate occasional spike (e.g., video download)
        if random.random() < 0.02:  # 2% chance every update
            spike = random.uniform(0.1, 0.3)  # 100-300MB spike
            self.current_used_gb += spike
        
        # Apply changes
        self.current_used_gb += base_growth + random_variation
        
        # Gradually update app categories to match overall growth
        total_size = sum(cat["size_gb"] for cat in self.app_categories.values())
        scale_factor = self.current_used_gb / total_size
        
        for category in self.app_categories.values():
            category["size_gb"] *= (1 + (category["growth_rate"] * 0.001))
        
        # Bounds check
        self.current_used_gb = min(self.current_used_gb, self.total_gb * 0.98)
        self.current_used_gb = max(self.current_used_gb, 40.0)
    
    def _get_storage_status(self, usage_percent: float) -> str:
        """Determine storage status based on usage percentage"""
        if usage_percent >= 90:
            return "critical"
        elif usage_percent >= 80:
            return "warning"
        elif usage_percent >= 70:
            return "caution"
        else:
            return "healthy"
    
    def _get_trend(self) -> str:
        """Get usage trend (increasing/stable/decreasing)"""
        # Simulate trend based on time
        trend_value = math.sin((datetime.now().timestamp() % 3600) / 600)
        
        if trend_value > 0.3:
            return "increasing"
        elif trend_value < -0.3:
            return "decreasing"
        else:
            return "stable"
    
    def get_app_details(self, app_name: str) -> dict:
        """Get details about a specific app"""
        if app_name in self.app_categories:
            info = self.app_categories[app_name]
            return {
                "name": app_name,
                "size_gb": info["size_gb"],
                "size_mb": info["size_gb"] * 1024,
                "growth_rate_daily_mb": info["growth_rate"] * 150,
                "cache_size_mb": random.uniform(50, 500),
                "last_used": "2 hours ago",
                "install_date": "30 days ago",
                "can_clear_cache": app_name in ["Cache", "Photos", "Videos"]
            }
        return None
    
    def clear_app_cache(self, app_name: str, size_mb: float) -> dict:
        """Simulate clearing cache for an app"""
        freed_space = size_mb / 1024  # Convert to GB
        self.current_used_gb -= freed_space
        
        if app_name in self.app_categories:
            # Reduce cache-like categories
            if "Cache" in self.app_categories:
                reduction = min(freed_space, self.app_categories["Cache"]["size_gb"])
                self.app_categories["Cache"]["size_gb"] -= reduction
        
        return {
            "status": "success",
            "app_name": app_name,
            "freed_space_mb": size_mb,
            "freed_space_gb": freed_space,
            "new_used_gb": round(self.current_used_gb, 2),
            "new_free_gb": round(self.total_gb - self.current_used_gb, 2)
        }
