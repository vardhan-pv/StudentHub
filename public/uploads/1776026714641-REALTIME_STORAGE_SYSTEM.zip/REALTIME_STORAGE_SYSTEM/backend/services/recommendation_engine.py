"""
Recommendation Engine
Generates smart, personalized recommendations based on storage data
"""

from datetime import datetime
from typing import List, Dict
import random

class RecommendationEngine:
    """Generate intelligent storage optimization recommendations"""
    
    def __init__(self):
        self.recommendation_history: List[Dict] = []
        self.action_impact_model = {
            "clear_cache": {"freed_space_mb": 500, "frequency": "daily"},
            "delete_old_videos": {"freed_space_mb": 2000, "frequency": "weekly"},
            "remove_duplicate_photos": {"freed_space_mb": 800, "frequency": "monthly"},
            "uninstall_unused_app": {"freed_space_mb": 500, "frequency": "weekly"},
            "cloud_backup": {"freed_space_mb": 1000, "frequency": "weekly"}
        }
    
    def generate_recommendations(
        self,
        storage_data: Dict,
        predictions: Dict,
        historical_data: List[Dict]
    ) -> List[Dict]:
        """
        Generate personalized recommendations
        
        Returns:
            List of recommendations sorted by impact
        """
        recommendations = []
        
        # Get storage status
        usage_percent = storage_data.get('usage_percent', 0)
        categories = storage_data.get('categories', [])
        
        # 1. Category-based recommendations
        category_recs = self._generate_category_recommendations(categories, usage_percent)
        recommendations.extend(category_recs)
        
        # 2. Growth-based recommendations
        growth_recs = self._generate_growth_recommendations(historical_data, predictions, usage_percent)
        recommendations.extend(growth_recs)
        
        # 3. Trend-based recommendations
        trend_recs = self._generate_trend_recommendations(storage_data)
        recommendations.extend(trend_recs)
        
        # 4. Proactive recommendations
        if usage_percent < 70:
            proactive_recs = self._generate_proactive_recommendations()
            recommendations.extend(proactive_recs)
        
        # Sort by priority and impact
        recommendations.sort(key=lambda x: (
            -x.get('priority_score', 0),
            -x.get('freed_space_mb', 0)
        ))
        
        # Add recommendations to history
        for rec in recommendations:
            self.recommendation_history.append({
                **rec,
                "generated_at": datetime.now().isoformat()
            })
        
        # Keep last 500 recommendations
        self.recommendation_history = self.recommendation_history[-500:]
        
        return recommendations[:5]  # Return top 5
    
    def _generate_category_recommendations(
        self,
        categories: List[Dict],
        usage_percent: float
    ) -> List[Dict]:
        """Generate recommendations based on category sizes"""
        recommendations = []
        
        for category in categories:
            name = category.get('name', '')
            size_gb = category.get('size_gb', 0)
            size_mb = category.get('size_mb', 0)
            icon = category.get('icon', '📁')
            
            # Photos recommendations
            if name == 'Photos' and size_gb > 25:
                rec = {
                    "id": f"rec_photos_{datetime.now().timestamp()}",
                    "type": "cloud_backup_photos",
                    "title": "📷 Back Up Old Photos to Cloud",
                    "description": f"You have {size_gb:.1f}GB of photos. Moving old ones to cloud can save ~50% space.",
                    "current_size_gb": size_gb,
                    "freed_space_mb": int(size_gb * 500),
                    "action": {
                        "type": "cloud_backup",
                        "target": "photos",
                        "params": {"keep_local_days": 30}
                    },
                    "impact": "high",
                    "difficulty": "easy",
                    "time_estimate": "2 minutes",
                    "priority_score": 9 if usage_percent > 80 else 7,
                    "icon": "📷",
                    "benefits": [
                        "Free up 1-2 GB of space",
                        "Keep recent photos locally",
                        "Automatic cloud sync"
                    ]
                }
                recommendations.append(rec)
            
            # Videos recommendations
            if name == 'Videos' and size_gb > 10:
                rec = {
                    "id": f"rec_videos_{datetime.now().timestamp()}",
                    "type": "delete_old_videos",
                    "title": "🎬 Delete Old Downloaded Videos",
                    "description": f"Remove videos downloaded >30 days ago to free space.",
                    "current_size_gb": size_gb,
                    "freed_space_mb": int(size_gb * 400),
                    "action": {
                        "type": "delete_files",
                        "target": "videos",
                        "params": {"older_than_days": 30}
                    },
                    "impact": "high",
                    "difficulty": "easy",
                    "time_estimate": "1 minute",
                    "priority_score": 8 if usage_percent > 80 else 6,
                    "icon": "🎬",
                    "benefits": [
                        f"Can free ~{int(size_gb * 400)}MB",
                        "Remove files you've already watched",
                        "Quick one-time action"
                    ]
                }
                recommendations.append(rec)
            
            # Cache recommendations
            if name == 'Cache' and size_gb > 3:
                rec = {
                    "id": f"rec_cache_{datetime.now().timestamp()}",
                    "type": "clear_app_cache",
                    "title": "♻️ Clear App Cache Files",
                    "description": f"App cache is using {size_gb:.1f}GB and can be safely cleared.",
                    "current_size_gb": size_gb,
                    "freed_space_mb": int(size_gb * 900),  # Cache is ~90% clearable
                    "action": {
                        "type": "clear_cache",
                        "scope": "system"
                    },
                    "impact": "medium",
                    "difficulty": "very_easy",
                    "time_estimate": "30 seconds",
                    "priority_score": 7 if usage_percent > 85 else 5,
                    "icon": "♻️",
                    "benefits": [
                        f"Instant {int(size_gb * 900)}MB freed",
                        "Apps will rebuild cache as needed",
                        "Safe to do regularly"
                    ]
                }
                recommendations.append(rec)
            
            # Documents/Downloads
            if name == 'Documents' and size_gb > 5:
                rec = {
                    "id": f"rec_docs_{datetime.now().timestamp()}",
                    "type": "cleanup_downloads",
                    "title": "📄 Review Downloaded Files",
                    "description": "Old downloads and documents can often be archived.",
                    "current_size_gb": size_gb,
                    "freed_space_mb": int(size_gb * 300),
                    "action": {
                        "type": "review_files",
                        "target": "downloads"
                    },
                    "impact": "low",
                    "difficulty": "easy",
                    "time_estimate": "5 minutes",
                    "priority_score": 4,
                    "icon": "📄",
                    "benefits": [
                        "Identify archivable content",
                        "Organize important files",
                        "Reduce clutter"
                    ]
                }
                recommendations.append(rec)
        
        return recommendations
    
    def _generate_growth_recommendations(
        self,
        historical_data: List[Dict],
        predictions: Dict,
        usage_percent: float
    ) -> List[Dict]:
        """Generate recommendations based on growth rate"""
        recommendations = []
        
        if not historical_data:
            return recommendations
        
        # Calculate growth rate
        if len(historical_data) >= 100:
            recent = historical_data[-100:]
            growth_gb = recent[-1]['used_gb'] - recent[0]['used_gb']
            growth_hours = len(recent) / 12 / 60  # 12 updates per day, 60 mins per hour
            hourly_growth_mb = (growth_gb * 1024) / max(growth_hours, 1)
        else:
            hourly_growth_mb = 0
        
        # If high growth rate
        if hourly_growth_mb > 50:
            rec = {
                "id": f"rec_growth_{datetime.now().timestamp()}",
                "type": "slow_growth",
                "title": "⚡ Identify High-Growth Apps",
                "description": f"Storage is growing quickly ({hourly_growth_mb:.0f}MB/hour). Check recent app activity.",
                "growth_rate_mb_per_hour": hourly_growth_mb,
                "freed_space_mb": 500,  # Estimated
                "action": {
                    "type": "analyze_app_growth",
                    "limit_to_apps": 5
                },
                "impact": "medium",
                "difficulty": "medium",
                "time_estimate": "3 minutes",
                "priority_score": 8 if usage_percent > 75 else 5,
                "icon": "⚡",
                "benefits": [
                    "Find culprit apps",
                    "Manage auto-sync features",
                    "Prevent future bloat"
                ]
            }
            recommendations.append(rec)
        
        # If approaching exhaustion
        day_7_pred = predictions.get('day_7', 0)
        if day_7_pred > 100 and usage_percent > 70:
            rec = {
                "id": f"rec_exhaustion_{datetime.now().timestamp()}",
                "type": "prevent_exhaustion",
                "title": "🚀 Take Proactive Action",
                "description": "Storage could be full soon. Implement storage plan now.",
                "predicted_full_day": 7,
                "freed_space_mb": 1000,
                "action": {
                    "type": "implement_plan",
                    "steps": ["cloud_backup", "clear_cache", "uninstall_unused"]
                },
                "impact": "high",
                "difficulty": "medium",
                "time_estimate": "10 minutes",
                "priority_score": 10,
                "icon": "🚀",
                "benefits": [
                    "Prevent system slowdown",
                    "Avoid installation failures",
                    "Maintain device health"
                ]
            }
            recommendations.append(rec)
        
        return recommendations
    
    def _generate_trend_recommendations(self, storage_data: Dict) -> List[Dict]:
        """Generate recommendations based on current trends"""
        recommendations = []
        trend = storage_data.get('trend', 'stable')
        
        if trend == "increasing":
            rec = {
                "id": f"rec_trend_{datetime.now().timestamp()}",
                "type": "enable_auto_cleanup",
                "title": "🔧 Enable Auto-Cleanup Features",
                "description": "Storage is increasing rapidly. Enable automatic cleanup features.",
                "freed_space_mb": 200,  # Estimated
                "action": {
                    "type": "enable_feature",
                    "features": ["auto_delete_temp", "auto_backup"]
                },
                "impact": "medium",
                "difficulty": "very_easy",
                "time_estimate": "1 minute",
                "priority_score": 6,
                "icon": "🔧",
                "benefits": [
                    "Automatic space management",
                    "Less manual cleanup needed",
                    "Runs in background"
                ]
            }
            recommendations.append(rec)
        
        return recommendations
    
    def _generate_proactive_recommendations(self) -> List[Dict]:
        """Generate proactive recommendations when storage is healthy"""
        recommendations = []
        
        rec = {
            "id": f"rec_proactive_{datetime.now().timestamp()}",
            "type": "storage_best_practices",
            "title": "💡 Storage Best Practices",
            "description": "Your storage is healthy. Keep it that way with these tips.",
            "freed_space_mb": 0,
            "action": {
                "type": "info",
                "tips": [
                    "Regular cloud backups",
                    "Monthly cache clearing",
                    "Review unused apps quarterly"
                ]
            },
            "impact": "low",
            "difficulty": "easy",
            "time_estimate": "5 minutes",
            "priority_score": 2,
            "icon": "💡",
            "benefits": [
                "Prevent future issues",
                "Maintain peak performance",
                "Extend device life"
            ]
        }
        recommendations.append(rec)
        
        return recommendations
    
    def estimate_action_impact(self, action_type: str) -> Dict:
        """Estimate space impact of an action"""
        return self.action_impact_model.get(action_type, {})
    
    def get_personalized_score(
        self,
        recommendation: Dict,
        storage_data: Dict
    ) -> float:
        """Calculate personalization score for a recommendation"""
        score = recommendation.get('priority_score', 0)
        
        # Boost score if storage is critical
        if storage_data.get('usage_percent', 0) > 90:
            score *= 1.5
        elif storage_data.get('usage_percent', 0) > 80:
            score *= 1.2
        
        return min(10, score)
