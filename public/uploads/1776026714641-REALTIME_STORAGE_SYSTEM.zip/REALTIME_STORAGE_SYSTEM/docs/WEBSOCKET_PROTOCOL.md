# WebSocket Protocol Documentation

## Connection

```javascript
const ws = new WebSocket('ws://localhost:8000/ws');
```

## Message Types

### 1. **Initial Data** (Server → Client)
Sent when client first connects.

```json
{
  "event": "initial_data",
  "storage": {
    "timestamp": "2024-04-12T10:30:00",
    "total_gb": 128,
    "used_gb": 45.5,
    "free_gb": 82.5,
    "usage_percent": 35.5,
    "status": "healthy",
    "trend": "stable",
    "daily_growth_mb": 150,
    "categories": [
      {
        "name": "Photos",
        "size_gb": 28.5,
        "size_mb": 29200,
        "percentage": 62.6,
        "growth_rate_daily_mb": 50,
        "icon": "📷"
      }
    ]
  },
  "history": [...],
  "predictions": {
    "day_7": 47.2,
    "day_15": 49.8,
    "day_30": 54.5
  }
}
```

### 2. **Storage Update** (Server → Client)
Continuous storage updates every 2 seconds.

```json
{
  "event": "storage_update",
  "timestamp": "2024-04-12T10:30:02",
  "storage": {
    "used_gb": 45.6,
    "free_gb": 82.4,
    "usage_percent": 35.6,
    "status": "healthy",
    "trend": "stable",
    "daily_growth_mb": 150
  }
}
```

### 3. **Prediction Update** (Server → Client)
Updated predictions based on latest data.

```json
{
  "event": "prediction_update",
  "timestamp": "2024-04-12T10:30:02",
  "predictions": {
    "day_7": 47.3,
    "day_15": 49.9,
    "day_30": 54.6
  },
  "confidence": {
    "short_term_7d": 0.85,
    "medium_term_15d": 0.72,
    "long_term_30d": 0.60,
    "data_quality_score": 0.72
  }
}
```

### 4. **Alert** (Server → Client)
Triggered when alert conditions are met.

```json
{
  "event": "alert",
  "data": {
    "id": "critical_1681298400.123",
    "type": "critical_threshold",
    "severity": "critical",
    "title": "🔴 CRITICAL: Storage Nearly Full",
    "message": "Storage usage at 92.5%. Immediate action required!",
    "usage_percent": 92.5,
    "threshold": 90,
    "icon": "🚨",
    "timestamp": "2024-04-12T10:35:00",
    "recommendations": [
      "Delete unused apps",
      "Clear cache files",
      "Remove old media files"
    ],
    "action_required": true
  }
}
```

### 5. **Recommendation** (Server → Client)
AI-generated recommendations for storage optimization.

```json
{
  "event": "recommendation",
  "data": {
    "id": "rec_photos_1681298400.123",
    "type": "cloud_backup_photos",
    "title": "📷 Back Up Old Photos to Cloud",
    "description": "You have 28.5GB of photos. Moving old ones to cloud can save ~50% space.",
    "current_size_gb": 28.5,
    "freed_space_mb": 14250,
    "action": {
      "type": "cloud_backup",
      "target": "photos",
      "params": {"keep_local_days": 30}
    },
    "impact": "high",
    "difficulty": "easy",
    "time_estimate": "2 minutes",
    "priority_score": 9,
    "icon": "📷",
    "benefits": [
      "Free up 1-2 GB of space",
      "Keep recent photos locally",
      "Automatic cloud sync"
    ]
  }
}
```

### 6. **System Alert** (Server → Client)
System-level alerts (connectivity, errors, etc).

```json
{
  "event": "system_alert",
  "type": "connection_restored",
  "message": "Connection restored. Resuming monitoring.",
  "severity": "info"
}
```

## Client → Server Messages

### 1. **Ping/Pong** (Keep-alive)
```json
{
  "type": "ping"
}
```

Response:
```json
{
  "event": "pong",
  "timestamp": "2024-04-12T10:30:00"
}
```

### 2. **Request What-If Simulation**
```json
{
  "type": "request_simulation",
  "app_name": "Photos",
  "size_mb": 500
}
```

Response:
```json
{
  "event": "simulation_result",
  "app_name": "Photos",
  "freed_space_gb": 0.5,
  "impact": "positive",
  "new_predictions": {
    "day_7": 46.8,
    "day_15": 49.4,
    "day_30": 54.1
  }
}
```

## Connection Lifecycle

1. **Client connects** → Server sends `initial_data`
2. **Continuous updates** → Server broadcasts every 2 seconds:
   - `storage_update`
   - `prediction_update`
   - `alert` (when triggered)
   - `recommendation` (when generated)
3. **Client can send** → `ping`, `request_simulation`
4. **Server responds** → `pong`, `simulation_result`
5. **Disconnection** → Client closes connection, server cleans up

## Error Handling

If connection drops:
- Client automatically attempts reconnection every 3 seconds
- Server maintains session history for 5 minutes
- All missed updates are sent upon reconnection

## Performance Optimizations

1. **Message Batching**: Multiple updates can be combined
2. **Delta Updates**: Only changed fields are sent
3. **Compression**: Consider gzip for large payloads
4. **Rate Limiting**: Max 100 connections per server

## Example Client Implementation

```javascript
const ws = new WebSocket('ws://localhost:8000/ws');

ws.onopen = () => {
  console.log('Connected');
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  switch(message.event) {
    case 'initial_data':
      updateDashboard(message);
      break;
    case 'storage_update':
      updateStorageWidget(message.storage);
      break;
    case 'alert':
      showAlert(message.data);
      break;
    case 'recommendation':
      addRecommendation(message.data);
      break;
  }
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
};

ws.onclose = () => {
  console.log('Disconnected. Reconnecting...');
  setTimeout(() => new WebSocket(url), 3000);
};

// Send message
ws.send(JSON.stringify({
  type: 'ping'
}));
```
