# 🚀 Production Deployment Guide

## Overview

This guide covers deploying the Real-Time Storage Intelligence System to production environments.

---

## Local Development Setup

### Quick Start
```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py

# Frontend (in new terminal)
cd frontend
npm install
npm run dev
```

Visit `http://localhost:5173`

---

## Docker Deployment

### Single Host (Docker Compose)

#### Prerequisites
- Docker 20.10+
- Docker Compose 2.0+

#### Deploy

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

**Services Started**:
- Backend: `http://localhost:8000`
- Frontend: `http://localhost:5173`
- Nginx: `http://localhost`

#### Verify Deployment

```bash
# Check backend health
curl http://localhost:8000/api/health

# Check frontend
curl http://localhost:5173

# View container status
docker-compose ps
```

#### Update Services

```bash
# Update backend
docker-compose up -d --build backend

# Update frontend
docker-compose up -d --build frontend

# Update all
docker-compose up -d --build
```

---

## Cloud Deployment

### AWS Elastic Container Service (ECS)

#### Create ECS Cluster

```bash
# Create cluster
aws ecs create-cluster --cluster-name storage-intelligence

# Register task definition
aws ecs register-task-definition --cli-input-json file://task-definition.json
```

#### Launch Service

```bash
# Create service
aws ecs create-service \
  --cluster storage-intelligence \
  --service-name storage-api \
  --task-definition storage-intelligence:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}"
```

### Google Cloud Run

#### Deploy Backend

```bash
# Build image
gcloud builds submit --tag gcr.io/PROJECT_ID/storage-backend ./backend

# Deploy
gcloud run deploy storage-backend \
  --image gcr.io/PROJECT_ID/storage-backend \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8000
```

#### Deploy Frontend

```bash
# Build image
gcloud builds submit --tag gcr.io/PROJECT_ID/storage-frontend ./frontend

# Deploy
gcloud run deploy storage-frontend \
  --image gcr.io/PROJECT_ID/storage-frontend \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 5173
```

### Azure Container Instances

#### Deploy with Docker

```bash
# Create resource group
az group create --name storage-rg --location eastus

# Deploy container
az container create \
  --resource-group storage-rg \
  --name storage-backend \
  --image docker.io/yourusername/storage-backend \
  --ports 8000 \
  --environment-variables TOTAL_STORAGE_GB=128

az container create \
  --resource-group storage-rg \
  --name storage-frontend \
  --image docker.io/yourusername/storage-frontend \
  --ports 5173
```

---

## Kubernetes Deployment

### Prerequisites
- Kubernetes 1.20+
- kubectl configured
- Docker images pushed to registry

### Create Namespace

```bash
kubectl create namespace storage-intelligence
```

### Deploy Backend

```yaml
# backend-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: storage-backend
  namespace: storage-intelligence
spec:
  replicas: 3
  selector:
    matchLabels:
      app: storage-backend
  template:
    metadata:
      labels:
        app: storage-backend
    spec:
      containers:
      - name: backend
        image: docker.io/yourusername/storage-backend:latest
        ports:
        - containerPort: 8000
        env:
        - name: TOTAL_STORAGE_GB
          value: "128"
        - name: DEBUG
          value: "false"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
```

### Deploy Frontend

```yaml
# frontend-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: storage-frontend
  namespace: storage-intelligence
spec:
  replicas: 2
  selector:
    matchLabels:
      app: storage-frontend
  template:
    metadata:
      labels:
        app: storage-frontend
    spec:
      containers:
      - name: frontend
        image: docker.io/yourusername/storage-frontend:latest
        ports:
        - containerPort: 5173
        livenessProbe:
          httpGet:
            path: /
            port: 5173
          initialDelaySeconds: 10
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /
            port: 5173
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "200m"
```

### Create Services

```yaml
# services.yaml
apiVersion: v1
kind: Service
metadata:
  name: storage-backend
  namespace: storage-intelligence
spec:
  selector:
    app: storage-backend
  ports:
  - port: 8000
    targetPort: 8000
  type: ClusterIP

---
apiVersion: v1
kind: Service
metadata:
  name: storage-frontend
  namespace: storage-intelligence
spec:
  selector:
    app: storage-frontend
  ports:
  - port: 80
    targetPort: 5173
  type: LoadBalancer
```

### Apply Configuration

```bash
# Apply deployments
kubectl apply -f backend-deployment.yaml
kubectl apply -f frontend-deployment.yaml
kubectl apply -f services.yaml

# Verify
kubectl get pods -n storage-intelligence
kubectl get svc -n storage-intelligence
```

### Monitor

```bash
# View logs
kubectl logs -n storage-intelligence deployment/storage-backend

# Port forward for testing
kubectl port-forward -n storage-intelligence svc/storage-backend 8000:8000
```

---

## Environment Configuration

### Environment Variables

**Backend** (`.env`):
```
DEBUG=false
TOTAL_STORAGE_GB=128
INITIAL_USED_GB=45
WARNING_THRESHOLD_PERCENT=80
CRITICAL_THRESHOLD_PERCENT=90
WS_UPDATE_INTERVAL_SECONDS=2
TIME_SERIES_MAX_POINTS=1440
```

**Frontend** (`.env`):
```
VITE_API_URL=https://api.yourdomain.com
VITE_WS_URL=wss://api.yourdomain.com
```

---

## SSL/TLS Configuration

### Let's Encrypt with Nginx

```nginx
# nginx.conf
server {
    listen 80;
    server_name api.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://backend:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## Monitoring & Logging

### Prometheus Metrics

```python
# Add to main.py
from prometheus_client import Counter, Histogram, generate_latest

ws_connections = Counter('websocket_connections_total', 'Total WebSocket connections')
request_duration = Histogram('request_duration_seconds', 'Request duration')

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")
```

### ELK Stack Integration

```yaml
# docker-compose.yml additions
elasticsearch:
  image: docker.elastic.co/elasticsearch/elasticsearch:8.0.0
  environment:
    - discovery.type=single-node

kibana:
  image: docker.elastic.co/kibana/kibana:8.0.0
  ports:
    - "5601:5601"

logstash:
  image: docker.elastic.co/logstash/logstash:8.0.0
  volumes:
    - ./logstash.conf:/usr/share/logstash/pipeline/logstash.conf
```

---

## Performance Tuning

### Backend Optimization

```python
# config.py
WS_UPDATE_INTERVAL_SECONDS = 5  # Reduce update frequency
TIME_SERIES_MAX_POINTS = 720    # Keep 12 hours of data
ALERT_HISTORY_LIMIT = 500       # Limit history
```

### Frontend Optimization

```javascript
// vite.config.js
export default {
  build: {
    minify: 'terser',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          recharts: ['recharts']
        }
      }
    }
  }
}
```

### Database Optimization

```python
# Use SQLite for persistence
from sqlalchemy import create_engine

engine = create_engine('sqlite:///storage.db', pool_pre_ping=True)

# Indexes
CREATE INDEX idx_storage_timestamp ON storage_data(timestamp);
CREATE INDEX idx_alerts_type ON alerts(type);
```

---

## Security Best Practices

### 1. Authentication

```python
# Add JWT authentication
from fastapi.security import HTTPBearer, HTTPAuthCredential

security = HTTPBearer()

@app.get("/api/protected")
async def protected_route(credentials: HTTPAuthCredential = Depends(security)):
    token = credentials.credentials
    # Validate token
    return {"data": "sensitive"}
```

### 2. CORS Security

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://yourdomain.com"],  # Specify domains
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
```

### 3. Rate Limiting

```python
from slowapi import Limiter

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@app.get("/api/storage/current")
@limiter.limit("100/minute")
async def get_current_storage(request: Request):
    pass
```

### 4. Input Validation

```python
from pydantic import BaseModel, Field

class AlertConfig(BaseModel):
    warning_percent: int = Field(ge=0, le=100)
    critical_percent: int = Field(ge=0, le=100)
    
    @validator('critical_percent')
    def critical_must_be_higher(cls, v, values):
        if 'warning_percent' in values and v <= values['warning_percent']:
            raise ValueError('critical_percent must be > warning_percent')
        return v
```

---

## Backup & Recovery

### Database Backup

```bash
# Backup
sqlite3 storage.db ".backup storage_backup.db"

# Restore
sqlite3 storage.db ".restore storage_backup.db"

# Automated backup (cron)
0 2 * * * sqlite3 /app/storage.db ".backup /backups/storage_$(date +\%Y\%m\%d).db"
```

### Configuration Backup

```bash
# Backup config
tar -czf config_backup.tar.gz ./backend/config.py ./frontend/.env

# Restore
tar -xzf config_backup.tar.gz
```

---

## Scaling Strategies

### Horizontal Scaling

1. **Load Balancer**: Use Nginx, HAProxy, or Cloud Load Balancer
2. **Database**: Migrate to PostgreSQL with read replicas
3. **Cache**: Add Redis for session/data caching
4. **CDN**: Use CloudFront/Cloudflare for static frontend

### Vertical Scaling

1. Increase server resources (CPU, RAM)
2. Optimize code (async/await, caching)
3. Use connection pooling
4. Compress WebSocket messages

---

## Troubleshooting

### High Memory Usage

```python
# Reduce time-series buffer
TIME_SERIES_MAX_POINTS = 360  # 6 hours instead of 24

# Clear old alerts periodically
alert_engine.clear_alert_history()
```

### WebSocket Disconnections

```javascript
// Increase reconnection timeout
const reconnectInterval = 5000;  // 5 seconds
const maxReconnectAttempts = 10;
```

### Slow API Responses

```python
# Add caching
from functools import lru_cache

@lru_cache(maxsize=128)
def get_current_storage():
    pass

# Cache decorator
from cachetools import TTLCache
cache = TTLCache(maxsize=100, ttl=60)
```

---

## Maintenance

### Regular Tasks

- **Daily**: Monitor logs, check alerts
- **Weekly**: Review performance metrics
- **Monthly**: Update dependencies, security patches
- **Quarterly**: Full backup, disaster recovery test

### Update Procedure

```bash
# Backend
docker-compose down
docker-compose up -d --build backend
docker-compose logs -f backend

# Frontend
docker-compose down
docker-compose up -d --build frontend
docker-compose logs -f frontend
```

---

## Support & Resources

- **Documentation**: See `/docs` folder
- **Issues**: Check GitHub Issues
- **FAQ**: See QUICKSTART.md
- **Community**: Contribute improvements

---

## Checklist for Production

- [ ] SSL/TLS configured
- [ ] Environment variables set
- [ ] Database backup automated
- [ ] Monitoring enabled
- [ ] Logging configured
- [ ] Rate limiting implemented
- [ ] Authentication enabled
- [ ] CORS properly configured
- [ ] Performance tested
- [ ] Disaster recovery plan
- [ ] Team trained
- [ ] Documentation updated

---

**Deployment Version**: 1.0.0
**Last Updated**: April 2026
