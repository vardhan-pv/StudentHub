# 🏗️ System Architecture Documentation

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│         WEB BROWSER / CLIENT APPLICATION                 │
│  ┌────────────────────────────────────────────────────┐ │
│  │          React Frontend (SPA)                       │ │
│  │  - Real-time Dashboard                             │ │
│  │  - Storage Charts (Recharts)                        │ │
│  │  - Alert Notifications                             │ │
│  │  - Recommendations Panel                           │ │
│  │  - What-If Simulator                               │ │
│  └────────────────────────────────────────────────────┘ │
└──────────────┬──────────────────────────────────────────┘
               │
        ╔══════╩═══════╗
        │               │
    HTTP/REST      WebSocket
   (REST API)      (Real-time)
        │               │
┌───────▼────────────────▼──────────────────────────────────┐
│           FastAPI Backend Server                          │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ API Routes & WebSocket Handler                       │ │
│  │  - /api/health                                       │ │
│  │  - /api/storage/*                                    │ │
│  │  - /api/predictions                                  │ │
│  │  - /api/alerts/*                                     │ │
│  │  - /api/recommendations                              │ │
│  │  - /api/what-if/*                                    │ │
│  │  - /ws (WebSocket)                                   │ │
│  └──────────────────────────────────────────────────────┘ │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ Core Services                                        │ │
│  │                                                      │ │
│  │  StorageMonitor                  WebSocketManager   │ │
│  │  ├─ Generate storage data        ├─ Manage conns   │ │
│  │  ├─ Realistic patterns           ├─ Broadcast msgs │ │
│  │  └─ App categories               └─ Connection pool│ │
│  │                                                      │ │
│  │  RecommendationEngine                               │ │
│  │  ├─ Category analysis                               │ │
│  │  ├─ Growth detection                                │ │
│  │  └─ Action prioritization                           │ │
│  └──────────────────────────────────────────────────────┘ │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ ML/Analytics Models                                  │ │
│  │                                                      │ │
│  │  StoragePredictionModel          AlertEngine        │ │
│  │  ├─ Linear regression            ├─ Threshold check│ │
│  │  ├─ Exponential smoothing        ├─ Spike detection│ │
│  │  ├─ Growth rate analysis         ├─ Category alerts│ │
│  │  └─ Exhaustion forecasting       └─ Cooldown logic │ │
│  └──────────────────────────────────────────────────────┘ │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ Background Tasks                                     │ │
│  │  - Continuous Monitoring Loop (every 2 seconds)     │ │
│  │  - Update Predictions                               │ │
│  │  - Check Alerts                                     │ │
│  │  - Generate Recommendations                         │ │
│  │  - Broadcast to Clients                             │ │
│  └──────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
               │
               │ (Optional: Data Persistence)
               │
┌──────────────▼──────────────────────────────────────────┐
│        Data Layer (Optional)                             │
│  ┌──────────────────────────────────────────────────────┐│
│  │  Time-Series Database                               ││
│  │  ├─ SQLite (development)                            ││
│  │  ├─ PostgreSQL (production)                         ││
│  │  └─ InfluxDB (time-series data)                     ││
│  └──────────────────────────────────────────────────────┘│
│  ┌──────────────────────────────────────────────────────┐│
│  │  In-Memory Cache (Current)                          ││
│  │  ├─ TimeSeriesBuffer (1440 points)                  ││
│  │  ├─ Alert History                                   ││
│  │  └─ Recommendation Cache                            ││
│  └──────────────────────────────────────────────────────┘│
└──────────────────────────────────────────────────────────┘
```

---

## Component Breakdown

### Frontend Components

```
App.jsx (Root Component)
├─ Header (Status, Connection)
├─ Dashboard.jsx (Main Layout)
│  ├─ StorageMonitor.jsx
│  │  └─ Real-time storage display with progress bar
│  ├─ StorageChart.jsx
│  │  └─ Line chart with historical + predicted data
│  ├─ AlertsPanel.jsx
│  │  └─ Alert list with severity indicators
│  ├─ RecommendationsPanel.jsx
│  │  └─ Expandable recommendation cards
│  ├─ WhatIfSimulator.jsx
│  │  └─ Interactive app deletion simulator
│  └─ StorageBreakdown.jsx
│     └─ Category pie/bar chart
└─ Footer (Info, Status)

Custom Hooks:
└─ useWebSocket.js
   ├─ Connection management
   ├─ Auto-reconnection
   └─ Message parsing
```

### Backend Structure

```
FastAPI Application (main.py)
├─ Initialization
│  ├─ CORS middleware
│  ├─ Global app state
│  └─ Startup/shutdown events
│
├─ API Routes (REST)
│  ├─ Health check
│  ├─ Storage endpoints
│  │  ├─ GET /api/storage/current
│  │  └─ GET /api/storage/history
│  ├─ Prediction endpoints
│  │  └─ GET /api/predictions
│  ├─ Alert endpoints
│  │  ├─ GET /api/alerts
│  │  └─ POST /api/config/alert-threshold
│  ├─ Recommendation endpoints
│  │  └─ GET /api/recommendations
│  ├─ What-If endpoints
│  │  └─ POST /api/what-if/delete-app
│  └─ Statistics endpoints
│     └─ GET /api/stats/system
│
├─ WebSocket Routes
│  └─ WebSocket /ws endpoint
│     ├─ Initial data broadcast
│     ├─ Continuous updates
│     └─ Client message handling
│
├─ Background Tasks
│  └─ Continuous Monitoring Loop
│     ├─ Storage data generation
│     ├─ Time-series buffering
│     ├─ Prediction updates
│     ├─ Alert checking
│     ├─ Recommendation generation
│     └─ WebSocket broadcasting
│
├─ Services
│  ├─ storage_monitor.py
│  │  ├─ Realistic data generation
│  │  ├─ App category management
│  │  └─ Cache simulation
│  │
│  ├─ websocket_manager.py
│  │  ├─ Connection pooling
│  │  ├─ Broadcasting
│  │  └─ Error handling
│  │
│  └─ recommendation_engine.py
│     ├─ Category analysis
│     ├─ Growth detection
│     └─ Action prioritization
│
├─ Models (ML)
│  ├─ storage_predictor.py
│  │  ├─ Linear regression
│  │  ├─ Exponential smoothing
│  │  ├─ Growth rate analysis
│  │  └─ Confidence scoring
│  │
│  └─ alert_engine.py
│     ├─ Threshold checking
│     ├─ Spike detection
│     ├─ Category alerts
│     └─ Alert deduplication
│
├─ Utilities
│  └─ time_series.py
│     ├─ Circular buffer
│     ├─ Statistical functions
│     └─ Trend analysis
│
└─ Configuration
   └─ config.py
      ├─ Settings management
      ├─ Environment variables
      └─ Default values
```

---

## Data Flow Diagrams

### Real-Time Update Cycle

```
┌─────────────────────┐
│  Monitoring Loop    │
│   (Every 2 sec)     │
└──────────┬──────────┘
           │
    ┌──────▼──────┐
    │   Generate  │
    │  Storage    │
    │   Data      │
    └──────┬──────┘
           │
    ┌──────▼──────────┐
    │  Update Time-   │
    │  Series Buffer  │
    └──────┬──────────┘
           │
    ┌──────▼──────┐
    │  Calculate  │
    │Predictions  │
    └──────┬──────┘
           │
    ┌──────▼──────┐
    │   Check     │
    │   Alerts    │
    └──────┬──────┘
           │
    ┌──────▼──────────────┐
    │  Generate            │
    │ Recommendations      │
    └──────┬───────────────┘
           │
    ┌──────▼──────┐
    │  Broadcast  │
    │    to All   │
    │   Clients   │
    └─────────────┘
```

### WebSocket Message Flow

```
Client                              Server
  │                                   │
  ├──────────── CONNECT ─────────────►│
  │                                   │
  │◄────── initial_data (large) ──────┤
  │                                   │
  │◄───── storage_update (small) ─────┤
  │◄───── prediction_update ──────────┤
  │◄───── alert (if triggered) ───────┤
  │◄───── recommendation ─────────────┤
  │                                   │
  ├────────── ping ──────────────────►│
  │◄─────────── pong ─────────────────┤
  │                                   │
  ├─ request_simulation ─────────────►│
  │◄─ simulation_result ──────────────┤
  │                                   │
  ├──────────── DISCONNECT ──────────►│
  │                                   │
```

### Prediction Algorithm Flow

```
Input: Historical Storage Data
       │
       ├─ Last N data points
       └─ Timestamps
       
       │
       ▼
┌──────────────────────────────┐
│  Method 1: Linear Regression │
└──────────┬───────────────────┘
           │
           ▼
    prediction_1 = slope × x + intercept
           
       │
       ├─────────────────────────┐
       │                         │
       ▼                         ▼
┌─────────────────────────┐  ┌──────────────────────────┐
│ Method 2: Exponential   │  │ Method 3: Growth Rate    │
│ Smoothing               │  │ Based Projection         │
└──────────┬──────────────┘  └──────────┬───────────────┘
           │                            │
           ▼                            ▼
  prediction_2 = smoothed_value   prediction_3 = recent_value +
                 + trend × days           (growth_per_unit × days)
           
       │                         │
       └───────────┬─────────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │  Weighted Average    │
        │  (40% + 35% + 25%)   │
        └──────────┬───────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │  Confidence Scoring  │
        │  - Data quality      │
        │  - Variance check    │
        │  - Data density      │
        └──────────┬───────────┘
                   │
                   ▼
        Final Prediction with
        Confidence Score
```

---

## Data Structures

### Storage Data Point

```python
{
    "timestamp": "2024-04-12T10:30:00",
    "total_gb": 128.0,
    "used_gb": 45.5,
    "free_gb": 82.5,
    "usage_percent": 35.5,
    "status": "healthy|caution|warning|critical",
    "trend": "increasing|decreasing|stable",
    "daily_growth_mb": 150,
    "categories": [
        {
            "name": "Photos",
            "size_gb": 28.5,
            "size_mb": 29200,
            "percentage": 62.6,
            "growth_rate_daily_mb": 50,
            "icon": "📷"
        }
    ]
}
```

### Alert Object

```python
{
    "id": "critical_1681298400.123",
    "type": "critical_threshold|warning_threshold|usage_spike|exhaustion_risk",
    "severity": "critical|warning|info",
    "title": "Alert Title",
    "message": "Detailed message",
    "icon": "🚨",
    "timestamp": "2024-04-12T10:35:00",
    "recommendations": ["action1", "action2"],
    "action_required": true,
    "metadata": {
        "usage_percent": 92.5,
        "threshold": 90
    }
}
```

### Recommendation Object

```python
{
    "id": "rec_photos_1681298400.123",
    "type": "cloud_backup_photos",
    "title": "Back Up Old Photos to Cloud",
    "description": "Description",
    "current_size_gb": 28.5,
    "freed_space_mb": 14250,
    "action": {
        "type": "cloud_backup|delete_files|clear_cache",
        "target": "photos",
        "params": {}
    },
    "impact": "high|medium|low",
    "difficulty": "very_easy|easy|medium|hard",
    "time_estimate": "2 minutes",
    "priority_score": 9,
    "benefits": ["Benefit 1", "Benefit 2"]
}
```

---

## Update Intervals & Performance

| Component | Update Interval | Volume |
|-----------|-----------------|--------|
| Storage Update | 2 seconds | ~5KB |
| Prediction Update | 2 seconds | ~100 bytes |
| Alert | On-trigger | Variable |
| Recommendation | 10 seconds | Variable |
| Full Sync | Connection | ~50KB |

---

## Scalability Considerations

### Current Bottlenecks

1. **In-Memory Storage**: Limited to 1440 data points
2. **Single Process**: No multi-worker setup
3. **No Database**: All data in memory
4. **Linear Broadcasting**: Single loop broadcasts to all clients

### Scaling Solutions

1. **Add Database**
   - SQLite for development
   - PostgreSQL for production
   - InfluxDB for time-series

2. **Horizontal Scaling**
   - Load balancer (Nginx, HAProxy)
   - Multiple backend instances
   - Shared data store
   - Message queue (RabbitMQ)

3. **Vertical Scaling**
   - More CPU cores (uvicorn workers)
   - More RAM (larger buffers)
   - Faster I/O

4. **Caching**
   - Redis for session data
   - Memory caching for frequent queries
   - Client-side caching

---

## Security Architecture

```
┌─────────────────────────────────────┐
│      Client (Browser/Mobile)        │
└──────────────┬──────────────────────┘
               │
        ┌──────▼──────────────┐
        │  SSL/TLS Encryption │
        └──────┬───────────────┘
               │
        ┌──────▼──────────────┐
        │  CORS Middleware    │
        └──────┬───────────────┘
               │
        ┌──────▼──────────────┐
        │ Rate Limiting       │
        └──────┬───────────────┘
               │
        ┌──────▼──────────────┐
        │ Input Validation    │
        └──────┬───────────────┘
               │
        ┌──────▼──────────────┐
        │ Authentication      │
        │ (JWT/OAuth)         │
        └──────┬───────────────┘
               │
        ┌──────▼──────────────┐
        │ Authorization       │
        │ (Role-based)        │
        └──────┬───────────────┘
               │
        ┌──────▼──────────────┐
        │ API Endpoint        │
        └─────────────────────┘
```

---

## Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Frontend | React 18 | UI Framework |
| | Vite | Build Tool |
| | Tailwind CSS | Styling |
| | Recharts | Charting |
| | Socket.io-client | WebSocket |
| Backend | FastAPI | API Framework |
| | Uvicorn | ASGI Server |
| | WebSockets | Real-time |
| | Pydantic | Validation |
| | NumPy | Math/Stats |
| | Pandas | Data Manipulation |
| | scikit-learn | ML Models |
| Deployment | Docker | Containerization |
| | Docker Compose | Orchestration |
| | Kubernetes | Container Orchestration |
| | Nginx | Reverse Proxy |
| Monitoring | Prometheus | Metrics |
| | Grafana | Dashboards |
| | ELK Stack | Logging |

---

## Deployment Architecture

```
Development
  ├─ React Dev Server (Port 5173)
  └─ FastAPI Dev Server (Port 8000)

Production
  ├─ Nginx (Reverse Proxy)
  │  ├─ Port 80 → 443 redirect
  │  └─ Port 443 → API + Frontend
  │
  ├─ Backend Services (Scaled)
  │  ├─ FastAPI Instance 1
  │  ├─ FastAPI Instance 2
  │  └─ FastAPI Instance N
  │
  ├─ Frontend CDN
  │  └─ CloudFlare/CloudFront
  │
  ├─ Database (Optional)
  │  └─ PostgreSQL Cluster
  │
  ├─ Cache (Optional)
  │  └─ Redis
  │
  └─ Monitoring
     ├─ Prometheus
     ├─ Grafana
     └─ ELK Stack
```

---

## Key Design Decisions

1. **WebSocket for Real-Time**: Lower latency than polling
2. **In-Memory Initially**: Faster, simpler setup
3. **Multiple Prediction Methods**: Better accuracy, confidence scoring
4. **Threshold-Based Alerts**: Easy to configure, efficient
5. **Modular Services**: Easy to test, maintain, scale
6. **Docker Deployment**: Consistent across environments
7. **React SPA**: Fast, responsive frontend

---

## Future Enhancements

1. Mobile app integration (native APIs)
2. Machine learning improvements (LSTM, Prophet)
3. Distributed tracing (Jaeger)
4. Advanced analytics (ML-based anomaly detection)
5. Multi-device support
6. Cloud backup integration
7. Advanced permissions system
8. Real-time collaboration

---

**Version**: 1.0.0
**Last Updated**: April 2026
