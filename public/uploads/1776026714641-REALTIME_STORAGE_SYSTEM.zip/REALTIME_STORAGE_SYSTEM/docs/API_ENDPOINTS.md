# REST API Endpoints Documentation

## Base URL
```
http://localhost:8000
```

## Health & Status

### Health Check
```
GET /api/health
```

**Response (200)**:
```json
{
  "status": "healthy",
  "timestamp": "2024-04-12T10:30:00",
  "monitoring": true,
  "connected_clients": 5
}
```

---

## Storage Endpoints

### Get Current Storage
```
GET /api/storage/current
```

**Response (200)**:
```json
{
  "status": "success",
  "data": {
    "timestamp": "2024-04-12T10:30:00",
    "total_gb": 128,
    "used_gb": 45.5,
    "free_gb": 82.5,
    "usage_percent": 35.5,
    "status": "healthy",
    "trend": "stable",
    "daily_growth_mb": 150,
    "categories": [
      {
        "name": "Photos",
        "size_gb": 28.5,
        "size_mb": 29200,
        "percentage": 62.6,
        "growth_rate_daily_mb": 50,
        "icon": "📷"
      }
    ],
    "largest_category": "Photos",
    "warning_threshold": 80,
    "critical_threshold": 90
  },
  "timestamp": "2024-04-12T10:30:00"
}
```

### Get Storage History
```
GET /api/storage/history?limit=100
```

**Query Parameters**:
- `limit` (optional): Number of records to return (default: 100, max: 1000)

**Response (200)**:
```json
{
  "status": "success",
  "data": [
    {
      "timestamp": "2024-04-12T10:29:58",
      "total_gb": 128,
      "used_gb": 45.4,
      "free_gb": 82.6,
      "usage_percent": 35.4,
      "status": "healthy",
      "trend": "stable",
      "daily_growth_mb": 150
    }
  ],
  "count": 100
}
```

---

## Prediction Endpoints

### Get Predictions
```
GET /api/predictions?days_ahead=30
```

**Query Parameters**:
- `days_ahead` (optional): Number of days to predict (default: 30)

**Response (200)**:
```json
{
  "status": "success",
  "data": {
    "day_7": 47.2,
    "day_15": 49.8,
    "day_30": 54.5
  },
  "timestamp": "2024-04-12T10:30:00"
}
```

**Response (400)** - Not enough data:
```json
{
  "detail": "Not enough data for predictions"
}
```

---

## Alert Endpoints

### Get Alerts
```
GET /api/alerts?limit=50
```

**Query Parameters**:
- `limit` (optional): Number of alerts to return (default: 50, max: 500)

**Response (200)**:
```json
{
  "status": "success",
  "data": [
    {
      "id": "critical_1681298400.123",
      "type": "critical_threshold",
      "severity": "critical",
      "title": "🔴 CRITICAL: Storage Nearly Full",
      "message": "Storage usage at 92.5%. Immediate action required!",
      "usage_percent": 92.5,
      "threshold": 90,
      "icon": "🚨",
      "timestamp": "2024-04-12T10:35:00",
      "recommendations": [
        "Delete unused apps",
        "Clear cache files"
      ],
      "action_required": true
    }
  ],
  "count": 5
}
```

### Set Alert Thresholds
```
POST /api/config/alert-threshold
```

**Request Body**:
```json
{
  "warning_percent": 80,
  "critical_percent": 90
}
```

**Response (200)**:
```json
{
  "status": "success",
  "warning_threshold": 80,
  "critical_threshold": 90
}
```

**Response (400)** - Invalid values:
```json
{
  "detail": "Invalid threshold values"
}
```

---

## Recommendation Endpoints

### Get Recommendations
```
GET /api/recommendations
```

**Response (200)**:
```json
{
  "status": "success",
  "data": [
    {
      "id": "rec_photos_1681298400.123",
      "type": "cloud_backup_photos",
      "title": "📷 Back Up Old Photos to Cloud",
      "description": "You have 28.5GB of photos. Moving old ones to cloud can save ~50% space.",
      "current_size_gb": 28.5,
      "freed_space_mb": 14250,
      "action": {
        "type": "cloud_backup",
        "target": "photos",
        "params": {"keep_local_days": 30}
      },
      "impact": "high",
      "difficulty": "easy",
      "time_estimate": "2 minutes",
      "priority_score": 9,
      "icon": "📷",
      "benefits": [
        "Free up 1-2 GB of space",
        "Keep recent photos locally"
      ]
    }
  ],
  "timestamp": "2024-04-12T10:30:00"
}
```

---

## What-If Simulation

### Simulate App Deletion
```
POST /api/what-if/delete-app
```

**Query Parameters**:
- `app_name` (required): Name of the app
- `size_mb` (required): Size of app in MB

**Example**:
```
POST /api/what-if/delete-app?app_name=Photos&size_mb=500
```

**Response (200)**:
```json
{
  "status": "success",
  "app_name": "Photos",
  "freed_space_gb": 0.5,
  "current_state": {
    "used_gb": 45.5,
    "free_gb": 82.5,
    "usage_percent": 35.5
  },
  "simulated_state": {
    "used_gb": 45.0,
    "free_gb": 83.0,
    "usage_percent": 35.2
  },
  "impact_on_predictions": {
    "day_7": 46.8,
    "day_15": 49.4,
    "day_30": 54.1
  },
  "recommendation": "safe_to_delete"
}
```

---

## Statistics Endpoints

### Get System Statistics
```
GET /api/stats/system
```

**Response (200)**:
```json
{
  "status": "success",
  "data": {
    "total_data_points": 1440,
    "uptime_minutes": 45.5,
    "avg_daily_growth_gb": 0.15,
    "prediction_accuracy": "N/A",
    "connected_clients": 3,
    "monitoring_status": "active"
  }
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "detail": "Invalid parameters"
}
```

### 404 Not Found
```json
{
  "detail": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "detail": "Internal server error"
}
```

---

## Rate Limiting

- **WebSocket**: 100 concurrent connections max
- **REST API**: 100 requests per minute per IP
- **Updates**: Sent every 2 seconds

---

## Example Requests

### Using cURL

**Get current storage**:
```bash
curl -X GET http://localhost:8000/api/storage/current
```

**Get predictions**:
```bash
curl -X GET "http://localhost:8000/api/predictions?days_ahead=30"
```

**Set alert threshold**:
```bash
curl -X POST http://localhost:8000/api/config/alert-threshold \
  -H "Content-Type: application/json" \
  -d '{"warning_percent": 75, "critical_percent": 85}'
```

**Simulate app deletion**:
```bash
curl -X POST "http://localhost:8000/api/what-if/delete-app?app_name=Photos&size_mb=500"
```

### Using JavaScript

```javascript
// Get current storage
fetch('http://localhost:8000/api/storage/current')
  .then(res => res.json())
  .then(data => console.log(data));

// Get recommendations
fetch('http://localhost:8000/api/recommendations')
  .then(res => res.json())
  .then(data => console.log(data));

// Simulate app deletion
fetch('http://localhost:8000/api/what-if/delete-app?app_name=Photos&size_mb=500', {
  method: 'POST'
})
  .then(res => res.json())
  .then(data => console.log(data));
```

---

## API Versioning

Current version: **v1** (implicit in `/api/` prefix)

Future versions will use `/api/v2/`, etc.
