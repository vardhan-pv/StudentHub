# 🚀 Quick Start Guide

## Prerequisites

- **Python 3.9+** (for backend)
- **Node.js 16+** (for frontend)
- **Git** (optional)

---

## Installation & Setup

### 1️⃣ Backend Setup

#### Clone/Extract Project
```bash
cd real-time-storage-system/backend
```

#### Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

#### Install Dependencies
```bash
pip install -r requirements.txt
```

#### Run Backend Server
```bash
python main.py
```

**Expected Output**:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
INFO:     🚀 Storage Intelligence System starting...
INFO:     ✅ System ready for connections
INFO:     📊 Starting continuous monitoring loop...
```

✅ Backend is now running on `http://localhost:8000`

---

### 2️⃣ Frontend Setup

#### Open New Terminal
```bash
cd real-time-storage-system/frontend
```

#### Install Dependencies
```bash
npm install
```

#### Run Development Server
```bash
npm run dev
```

**Expected Output**:
```
  VITE v5.0.8  ready in 234 ms

  ➜  Local:   http://localhost:5173/
  ➜  press h to show help
```

✅ Frontend is now running on `http://localhost:5173`

---

## 🎯 First Run

1. **Open Browser**: Go to `http://localhost:5173`
2. **See Dashboard**: Real-time storage monitor should load
3. **Check Connection**: Status indicator should show "Connected" (green dot)
4. **View Live Updates**: Storage, alerts, and recommendations update in real-time

---

## 📊 Dashboard Features

### Main Components

| Component | Purpose | Update Frequency |
|-----------|---------|-----------------|
| **Storage Monitor** | Show current usage | Every 2 seconds |
| **Storage Chart** | Show trends & predictions | Every 2 seconds |
| **Alerts Panel** | Display active alerts | Real-time |
| **Recommendations** | AI suggestions | Every 10 seconds |
| **What-If Simulator** | Predict impact of deletion | On-demand |
| **Storage Breakdown** | Category breakdown | Every 2 seconds |

---

## 🔧 Configuration

### Backend Configuration

Edit `backend/config.py`:

```python
TOTAL_STORAGE_GB = 128.0          # Device storage capacity
INITIAL_USED_GB = 45.0             # Starting used space
WARNING_THRESHOLD_PERCENT = 80      # Yellow alert
CRITICAL_THRESHOLD_PERCENT = 90     # Red alert
WS_UPDATE_INTERVAL_SECONDS = 2      # Update frequency
```

### Alert Thresholds (Runtime)

**Via API**:
```bash
curl -X POST http://localhost:8000/api/config/alert-threshold \
  -H "Content-Type: application/json" \
  -d '{"warning_percent": 75, "critical_percent": 85}'
```

---

## 🌐 API Testing

### Using REST API

#### Health Check
```bash
curl http://localhost:8000/api/health
```

#### Get Current Storage
```bash
curl http://localhost:8000/api/storage/current
```

#### Get Predictions
```bash
curl http://localhost:8000/api/predictions
```

#### Get Alerts
```bash
curl http://localhost:8000/api/alerts
```

#### Get Recommendations
```bash
curl http://localhost:8000/api/recommendations
```

### Using WebSocket

```javascript
const ws = new WebSocket('ws://localhost:8000/ws');

ws.onopen = () => {
  console.log('Connected');
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Update:', data);
};

ws.onerror = (error) => {
  console.error('Error:', error);
};
```

---

## 📈 Simulate Real Scenarios

### Scenario 1: Storage Getting Full (Critical Alert)

The system simulates storage growth. To trigger critical alert:
1. Wait ~5-10 minutes for storage usage to reach 90%
2. Or modify `backend/services/storage_monitor.py` to increase growth rate

### Scenario 2: Test What-If Simulation

In frontend, go to "What-If Simulator" section:
1. Select an app (e.g., Photos)
2. Adjust size slider
3. Click "Run Simulation"
4. See predicted impact on storage

### Scenario 3: Test Predictions

Predictions automatically update based on historical data:
1. System displays 7, 15, and 30-day predictions
2. Predictions update every 2 seconds
3. Check "Storage Trend & Prediction" chart

---

## 🐛 Troubleshooting

### Issue: Frontend shows "Attempting to connect..."

**Solution**:
1. Check backend is running: `python main.py`
2. Verify backend URL in `frontend/src/hooks/useWebSocket.js`
3. Check console for errors (F12 → Console tab)

### Issue: WebSocket connection fails

**Solution**:
```bash
# Check if port 8000 is in use
lsof -i :8000  # macOS/Linux
netstat -ano | findstr :8000  # Windows

# Kill process if needed
kill -9 <PID>  # macOS/Linux
taskkill /PID <PID> /F  # Windows
```

### Issue: Frontend shows old data

**Solution**:
1. Hard refresh browser: `Ctrl+Shift+R` (Windows/Linux) or `Cmd+Shift+R` (Mac)
2. Clear cache: DevTools → Application → Clear Storage
3. Rebuild: `npm run build` then `npm run preview`

### Issue: High CPU usage

**Solution**:
1. Increase `WS_UPDATE_INTERVAL_SECONDS` in `backend/config.py` (default: 2)
2. Reduce `TIME_SERIES_MAX_POINTS` if storing too much data
3. Run on production server with more resources

---

## 📁 Project Structure

```
real-time-storage-system/
├── backend/
│   ├── main.py                 # FastAPI entry point
│   ├── config.py               # Configuration
│   ├── requirements.txt         # Python dependencies
│   ├── services/               # Business logic
│   │   ├── storage_monitor.py
│   │   ├── websocket_manager.py
│   │   └── recommendation_engine.py
│   ├── models/                 # ML models
│   │   ├── storage_predictor.py
│   │   └── alert_engine.py
│   └── utils/                  # Utilities
│       └── time_series.py
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx            # Main app
│   │   ├── components/        # React components
│   │   ├── hooks/             # Custom hooks
│   │   └── index.css          # Styles
│   ├── package.json           # Node dependencies
│   ├── vite.config.js         # Vite config
│   └── index.html             # Entry HTML
│
└── docs/
    ├── WEBSOCKET_PROTOCOL.md  # WebSocket docs
    ├── API_ENDPOINTS.md       # REST API docs
    └── DEPLOYMENT.md          # Production setup
```

---

## 📊 Performance Tips

1. **Reduce Update Frequency**: Change `WS_UPDATE_INTERVAL_SECONDS` to 5 or 10
2. **Limit Data Points**: Reduce `TIME_SERIES_MAX_POINTS` to 720 (12 hours)
3. **Enable Compression**: Use gzip for WebSocket messages
4. **Optimize Frontend**: Use React.memo for expensive components
5. **Database**: Consider SQLite/PostgreSQL for persistence instead of in-memory

---

## 🚀 Deployment (Production)

See `docs/DEPLOYMENT.md` for:
- Docker containerization
- Kubernetes deployment
- Cloud platforms (AWS, GCP, Azure)
- CI/CD pipelines
- Security considerations

---

## 📚 Documentation

- **API Endpoints**: `docs/API_ENDPOINTS.md`
- **WebSocket Protocol**: `docs/WEBSOCKET_PROTOCOL.md`
- **Architecture**: `docs/ARCHITECTURE.md`
- **Deployment**: `docs/DEPLOYMENT.md`

---

## 💡 Common Tasks

### Add New Alert Type
1. Edit `backend/models/alert_engine.py`
2. Add method: `_check_new_alert_type()`
3. Call in `check_alerts()`

### Modify Prediction Algorithm
1. Edit `backend/models/storage_predictor.py`
2. Update prediction methods
3. Test with historical data

### Add New Dashboard Widget
1. Create component in `frontend/src/components/`
2. Import in `Dashboard.jsx`
3. Add to layout grid

### Change Theme Colors
1. Edit `frontend/tailwind.config.js`
2. Update Tailwind theme colors
3. Rebuild frontend: `npm run build`

---

## 🆘 Support

- **Issues**: Check GitHub Issues
- **Questions**: See FAQ below
- **Bugs**: Submit bug report with logs

### FAQ

**Q: How often does data update?**
A: Every 2 seconds (configurable via `WS_UPDATE_INTERVAL_SECONDS`)

**Q: How far ahead are predictions?**
A: 7, 15, and 30 days by default

**Q: Can I use real device storage data?**
A: Yes! Replace `storage_monitor.py` with native Android/iOS APIs

**Q: Is data persistent?**
A: Currently in-memory only. Add SQLite/PostgreSQL for persistence.

**Q: How many users can connect?**
A: Default: 100 concurrent WebSocket connections

---

## ✅ Checklist for First Run

- [ ] Backend running on port 8000
- [ ] Frontend running on port 5173
- [ ] Browser shows "Connected" status
- [ ] Storage monitor updates every 2 seconds
- [ ] Alerts panel displays correctly
- [ ] Charts show real-time data
- [ ] Recommendations panel has items
- [ ] What-If simulator works
- [ ] No console errors

---

## 🎉 You're Ready!

Your real-time storage intelligence system is now running!

**Next Steps**:
1. Explore all features
2. Test different scenarios
3. Customize for your needs
4. Deploy to production (see `docs/DEPLOYMENT.md`)
5. Integrate with your mobile app

Happy monitoring! 📊✨
